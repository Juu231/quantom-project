CREATE SCHEMA fastfood_systemFinal;
USE fastfood_systemFinal;

-- 1. Create the users table first (The Master Audit Trail)
CREATE TABLE users (
    userID VARCHAR(10) PRIMARY KEY,
    fullName VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(255),
    role VARCHAR(30),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkUsersCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkUsersUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

-- 2. Create independent tables that only rely on users
CREATE TABLE stores (
    storeNumber CHAR(5) PRIMARY KEY,
    storeAddress TEXT,
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkStoresCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkStoresUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE customers (
    customerID CHAR(10) PRIMARY KEY,
    customerName VARCHAR(100),
    phoneNumber VARCHAR(15),
    email VARCHAR(100),
    password VARCHAR(255),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkCustomersCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkCustomersUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE promotions (
    promoCode VARCHAR(20) PRIMARY KEY,
    discountAmount TINYINT,
    startDate DATE,
    endDate DATE,
    isActive TINYINT(1),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkPromotionsCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkPromotionsUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE orderStatus (
    statusID TINYINT PRIMARY KEY,
    statusName VARCHAR(20),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkOrderStatusCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkOrderStatusUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE menu (
    menuID CHAR(10) PRIMARY KEY,
    comboItem VARCHAR(50),
    itemDescription TEXT,
    itemPrice BIGINT,
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkMenuCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkMenuUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE suppliers (
    supplierID CHAR(5) PRIMARY KEY,
    supplierName VARCHAR(100),
    contactPerson VARCHAR(50),
    supplierAddress TEXT,
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkSuppliersCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkSuppliersUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

-- 3. Create dependent tables
CREATE TABLE crews (
    crewID CHAR(10) PRIMARY KEY,
    fullName VARCHAR(100),
    email VARCHAR(100),
    password VARCHAR(255),
    position VARCHAR(50),
    phoneNumber VARCHAR(15),
    storeNumber CHAR(5),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkCrewsStoreNumber FOREIGN KEY (storeNumber) REFERENCES stores(storeNumber),
    CONSTRAINT fkCrewsCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkCrewsUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE inventory (
    ingredientID CHAR(7) PRIMARY KEY,
    ingredientName VARCHAR(50),
    categoryIngredient VARCHAR(25),
    currentStock INT,
    reorderLevel INT,
    reorderAmount INT,
    wastedAmount INT,
    ingredientCost BIGINT,
    supplierID CHAR(5),
    lastUpdateRestock DATETIME,
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    CONSTRAINT fkInventorySupplierId FOREIGN KEY (supplierID) REFERENCES suppliers(supplierID),
    CONSTRAINT fkInventoryCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkInventoryUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

-- 4. Create mapping/transactional tables
CREATE TABLE recipe (
    menuID CHAR(10),
    ingredientID CHAR(7),
    quantityItem INT,
    unitItem VARCHAR(20),
    createdAt TIMESTAMP,
    createdBy VARCHAR(10),
    updatedAt TIMESTAMP,
    updatedBy VARCHAR(10),
    PRIMARY KEY (menuID, ingredientID),
    CONSTRAINT fkRecipeMenuId FOREIGN KEY (menuID) REFERENCES menu(menuID),
    CONSTRAINT fkRecipeIngredientId FOREIGN KEY (ingredientID) REFERENCES inventory(ingredientID),
    CONSTRAINT fkRecipeCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
    CONSTRAINT fkRecipeUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID)
);

CREATE TABLE orders (
    orderNumber CHAR(12) PRIMARY KEY,
    orderDate DATETIME,
    storeNumber CHAR(5),
    crewID CHAR(10),
    customerID CHAR(10),
    promoCode VARCHAR(20),
    statusID TINYINT,
    totalAmount BIGINT,
    createdBy VARCHAR(10),
    CONSTRAINT fkOrdersStoreNumber FOREIGN KEY (storeNumber) REFERENCES stores(storeNumber),
    CONSTRAINT fkOrdersCrewId FOREIGN KEY (crewID) REFERENCES crews(crewID),
    CONSTRAINT fkOrdersCustomerId FOREIGN KEY (customerID) REFERENCES customers(customerID),
    CONSTRAINT fkOrdersPromoCode FOREIGN KEY (promoCode) REFERENCES promotions(promoCode),
    CONSTRAINT fkOrdersStatusId FOREIGN KEY (statusID) REFERENCES orderStatus(statusID),
    CONSTRAINT fkOrdersCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID)
);

ALTER TABLE orders
ADD COLUMN createdAt TIMESTAMP,
ADD COLUMN updatedAt TIMESTAMP,
ADD COLUMN updatedBy VARCHAR(10),
ADD CONSTRAINT fkOrdersUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID);

CREATE TABLE orderItems (
    orderNumber CHAR(12),
    menuID CHAR(10),
    quantityItem INT,
    subtotal BIGINT,
    PRIMARY KEY (orderNumber, menuID),
    CONSTRAINT fkOrderItemsOrderNumber FOREIGN KEY (orderNumber) REFERENCES orders(orderNumber),
    CONSTRAINT fkOrderItemsMenuId FOREIGN KEY (menuID) REFERENCES menu(menuID)
);

ALTER TABLE orderItems
ADD COLUMN createdAt TIMESTAMP,
ADD COLUMN createdBy VARCHAR(10),
ADD COLUMN updatedAt TIMESTAMP,
ADD COLUMN updatedBy VARCHAR(10),
ADD CONSTRAINT fkOrderItemsCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
ADD CONSTRAINT fkOrderItemsUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID);

CREATE TABLE supplierPurchases (
    purchaseID CHAR(12) PRIMARY KEY,
    purchaseDate DATETIME,
    storeNumber CHAR(5),
    supplierID CHAR(5),
    totalCost BIGINT,
    createdBy VARCHAR(10),
    CONSTRAINT fkSupplierPurchasesStoreNumber FOREIGN KEY (storeNumber) REFERENCES stores(storeNumber),
    CONSTRAINT fkSupplierPurchasesSupplierId FOREIGN KEY (supplierID) REFERENCES suppliers(supplierID),
    CONSTRAINT fkSupplierPurchasesCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID)
);

ALTER TABLE supplierPurchases
ADD COLUMN createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
ADD COLUMN updatedBy VARCHAR(10),
ADD CONSTRAINT fkSupplierPurchasesUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID);

CREATE TABLE supplierPurchaseItem (
    purchaseID CHAR(12),
    ingredientID CHAR(7),
    purchaseQuantity INT,
    itemCost BIGINT,
    PRIMARY KEY (purchaseID, ingredientID),
    CONSTRAINT fkSupplierPurchaseItemPurchaseId FOREIGN KEY (purchaseID) REFERENCES supplierPurchases(purchaseID),
    CONSTRAINT fkSupplierPurchaseItemIngredientId FOREIGN KEY (ingredientID) REFERENCES inventory(ingredientID)
);

ALTER TABLE supplierPurchaseItem
ADD COLUMN createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN createdBy VARCHAR(10),
ADD COLUMN updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
ADD COLUMN updatedBy VARCHAR(10),
ADD CONSTRAINT fkSupplierPurchaseItemCreatedBy FOREIGN KEY (createdBy) REFERENCES users(userID),
ADD CONSTRAINT fkSupplierPurchaseItemUpdatedBy FOREIGN KEY (updatedBy) REFERENCES users(userID);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users
INSERT INTO users (userID, fullName, email, password, role, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('SYSTEM', 'Sistem Otomasi Pusat', 'core@admin.sys', 'systemcore', 'System Core', '2026-04-01 00:00:00', 'SYSTEM', '2026-04-01 00:00:00', 'SYSTEM'),
('ADMIN_01', 'Aditya Pratama Kusuma', 'aditya@admin.sys', 'admin123', 'Super Admin', '2026-04-01 08:30:00', 'SYSTEM', '2026-04-01 08:30:00', 'SYSTEM'),
('ADMIN_02', 'Bambang Herlambang Susilo', 'bambang@admin.sys', 'admin123', 'Inventory Manager', '2026-04-01 08:45:00', 'SYSTEM', '2026-04-01 08:45:00', 'SYSTEM'),
('ADMIN_03', 'Siti Aminah Rahayu', 'siti@admin.sys', 'admin123', 'Store Manager', '2026-04-01 09:00:00', 'SYSTEM', '2026-04-01 09:00:00', 'SYSTEM'),
('ADMIN_04', 'Fajar Ramadhan Saputra', 'fajar@admin.sys', 'admin123', 'Shift Supervisor', '2026-04-01 09:15:00', 'SYSTEM', '2026-04-01 09:15:00', 'SYSTEM');

-- 2. Stores
INSERT INTO stores (storeNumber, storeAddress, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('ST001', 'UPH Tower, Lippo Village, Tangerang', '2026-04-15 10:00:00', 'ADMIN_01', '2026-04-15 10:00:00', 'ADMIN_01');

-- 3. orderStatus
INSERT INTO orderStatus (statusID, statusName, createdAt, createdBy, updatedAt, updatedBy) VALUES 
(1, 'Pending', '2026-04-01 01:00:00', 'SYSTEM', '2026-04-01 01:00:00', 'SYSTEM'),
(2, 'Preparing', '2026-04-01 01:00:00', 'SYSTEM', '2026-04-01 01:00:00', 'SYSTEM'),
(3, 'Completed', '2026-04-01 01:00:00', 'SYSTEM', '2026-04-01 01:00:00', 'SYSTEM'),
(4, 'Cancelled', '2026-04-01 01:00:00', 'SYSTEM', '2026-04-01 01:00:00', 'SYSTEM');


-- 6. Menu
INSERT INTO menu (menuID, comboItem, itemDescription, itemPrice, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('MN01', 'Classic Burger', 'Burger sapi panggang dengan selada dan saus spesial.', 35000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN02', 'Cheese Burger', 'Classic Burger dengan tambahan lapisan keju cheddar.', 42000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN03', 'Double Beef', 'Dua lapis beef patty premium.', 55000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN04', 'Chicken Burger', 'Daging ayam krispi dengan balutan tepung rahasia.', 32000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN05', 'Fried Chicken', 'Ayam goreng khas tekstur kulit renyah dan gurih.', 18000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN06', 'French Fries L', 'Kentang goreng impor taburan garam laut.', 20000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01'), 
('MN07', 'Nasi Ayam', 'Nasi hangat dengan ayam goreng pilihan.', 25000, '2026-04-15 10:15:00', 'ADMIN_01', '2026-04-15 10:15:00', 'ADMIN_01');

-- 7. Promotions
INSERT INTO promotions (promoCode, discountAmount, startDate, endDate, isActive, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('NOCODE', 0, '2000-01-01', '2099-12-31', 1, '2026-04-01 00:00:00', 'SYSTEM', '2026-04-01 00:00:00', 'SYSTEM'), 
('PROMO10', 10, '2026-04-01', '2026-04-30', 1, '2026-04-15 11:00:00', 'ADMIN_01', '2026-04-15 11:00:00', 'ADMIN_01'), 
('UPHSTUDENT', 15, '2026-01-01', '2026-12-31', 1, '2026-04-15 11:00:00', 'ADMIN_01', '2026-04-15 11:00:00', 'ADMIN_01'), 
('TEDX2026', 20, '2026-03-01', '2026-04-30', 1, '2026-04-15 11:00:00', 'ADMIN_01', '2026-04-15 11:00:00', 'ADMIN_01'), 
('EXPIRED50', 50, '2025-01-01', '2025-12-31', 0, '2026-04-15 11:00:00', 'ADMIN_01', '2026-04-15 11:00:00', 'ADMIN_01');

-- 8. Crews
INSERT INTO crews (crewID, fullName, email, password, position, phoneNumber, storeNumber, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('CR001', 'Budi Setiawan', 'budi.s@crew.sys', 'crew123', 'Kitchen Staff', '081298745521', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'), 
('CR002', 'Bambang Pamungkas', 'bambang.p@crew.sys', 'crew123', 'Cashier', '085711224390', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'), 
('CR003', 'Rina Sari Dewi', 'rina.s@crew.sys', 'crew123', 'Server', '081388762104', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'), 
('CR004', 'Andi Pratama Putra', 'andi.p@crew.sys', 'crew123', 'Kitchen Staff', '081900234112', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'), 
('CR005', 'Siska Kohl Putri', 'siska.k@crew.sys', 'crew123', 'Delivery', '082155663219', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR006', 'Bella Safira', 'bella.s@crew.sys', 'crew123', 'Cashier', '081234567802', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR007', 'Candra Gunawan', 'candra.g@crew.sys', 'crew123', 'Server', '081234567803', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR008', 'Deni Sumargo', 'deni.s@crew.sys', 'crew123', 'Delivery', '081234567804', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR009', 'Eka Ramdani', 'eka.r@crew.sys', 'crew123', 'Kitchen Staff', '081234567805', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR010', 'Fajar Alfian', 'fajar.a@crew.sys', 'crew123', 'Cashier', '081234567806', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR011', 'Gita Gutawa', 'gita.g@crew.sys', 'crew123', 'Server', '081234567807', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR012', 'Hadi Tjahjanto', 'hadi.t@crew.sys', 'crew123', 'Delivery', '081234567808', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR013', 'Indra Bekti', 'indra.b@crew.sys', 'crew123', 'Kitchen Staff', '081234567809', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR014', 'Joko Anwar', 'joko.a@crew.sys', 'crew123', 'Cashier', '081234567810', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03'),
('CR015', 'Kartika Putri', 'kartika.p@crew.sys', 'crew123', 'Server', '081234567811', 'ST001', '2026-04-15 11:30:00', 'ADMIN_03', '2026-04-15 11:30:00', 'ADMIN_03');

-- 9. Customers
INSERT INTO customers (customerID, customerName, phoneNumber, email, password, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('C01', 'Rizky Febian Adriansyah', '081211445566', 'rizky@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'), 
('C02', 'Anya Geraldine Puspita', '081233998877', 'anya@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'), 
('C03', 'Reza Rahadian Matulessy', '081255001122', 'reza@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'), 
('C04', 'Dian Sastrowardoyo', '081277334455', 'dian@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'), 
('C06', 'Chelsea Islan', '081222334455', 'chelsea@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C07', 'Iqbaal Ramadhan', '081233445566', 'iqbaal@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C08', 'Vanesha Prescilla', '081244556677', 'vanesha@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C09', 'Adipati Dolken', '081255667788', 'adipati@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C10', 'Guest Customer', 'Guest', 'Guest', 'Guest', '2026-04-16 09:00:00', 'SYSTEM', '2026-04-16 09:00:00', 'SYSTEM'),
('C11', 'Amanda Rawles', '081266778899', 'amanda@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C12', 'Jefri Nichol', '081277889900', 'jefri@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C13', 'Mawar Eva de Jongh', '081288990011', 'mawar@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C14', 'Angga Yunanda', '081299001122', 'angga@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C15', 'Zara Adhisty', '081200112233', 'zara@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C16', 'Joe Taslim', '081211112222', 'joe@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C17', 'Iko Uwais', '081222223333', 'iko@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C18', 'Yayan Ruhian', '081233334444', 'yayan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C19', 'Tara Basro', '081244445555', 'tara@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C20', 'Marissa Anita', '081255556666', 'marissa@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C21', 'Ario Bayu', '081266667777', 'ario@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C22', 'Lukman Sardi', '081277778888', 'lukman@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C23', 'Chicco Jerikho', '081288889999', 'chicco@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C24', 'Rio Dewanto', '081299990000', 'rio@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C25', 'Vino G. Bastian', '081311111111', 'vino@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C26', 'Marthino Lio', '081322222222', 'marthino@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C27', 'Putri Marino', '081333333333', 'putri.m@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C28', 'Dian Pelangi', '081344444444', 'dian.p@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C29', 'Luna Maya', '081355555555', 'luna@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C30', 'Ariel Noah', '081366666666', 'ariel@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C31', 'Bunga Citra Lestari', '081377777777', 'bcl@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C32', 'Afgan Syahreza', '081388888888', 'afgan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C33', 'Rossa Roslaina', '081399999999', 'rossa@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C34', 'Judika Sihotang', '081411111111', 'judika@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C35', 'Raisa Andriana', '081422222222', 'raisa@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C36', 'Isyana Sarasvati', '081433333333', 'isyana@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C37', 'Vidi Aldiano', '081444444444', 'vidi@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C38', 'Yura Yunita', '081455555555', 'yura@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C39', 'Kunto Aji', '081466666666', 'kunto@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C40', 'Pamungkas', '081477777777', 'pamungkas@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C41', 'Hindia', '081488888888', 'hindia@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C42', 'Nadin Amizah', '081499999999', 'nadin@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C43', 'Ardhito Pramono', '081511111111', 'ardhito@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C44', 'Tiara Andini', '081522222222', 'tiara@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C45', 'Lyodra Ginting', '081533333333', 'lyodra@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C46', 'Ziva Magnolya', '081544444444', 'ziva@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C47', 'Mahalini Raharja', '081555555555', 'mahalini@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C48', 'Keisya Levronka', '081566666666', 'keisya@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C49', 'Rizky Billar', '081577777777', 'billar@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C50', 'Lesti Kejora', '081588888888', 'lesti@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C51', 'Raffi Ahmad', '081611111111', 'raffi@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C52', 'Nagita Slavina', '081622222222', 'nagita@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C53', 'Baim Wong', '081633333333', 'baim@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C54', 'Paula Verhoeven', '081644444444', 'paula@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C55', 'Atta Halilintar', '081655555555', 'atta@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C56', 'Aurel Hermansyah', '081666666666', 'aurel@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C57', 'Anang Hermansyah', '081677777777', 'anang@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C58', 'Ashanty', '081688888888', 'ashanty@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C59', 'Deddy Corbuzier', '081699999999', 'deddy@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C60', 'Raditya Dika', '081711111111', 'raditya@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C61', 'Boy William', '081722222222', 'boy@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C62', 'Daniel Mananta', '081733333333', 'daniel@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C63', 'Vincent Rompies', '081744444444', 'vincent@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C64', 'Desta Mahendra', '081755555555', 'desta@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C65', 'Andre Taulany', '081766666666', 'andre@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C66', 'Sule', '081777777777', 'sule@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C67', 'Ayu Ting Ting', '081788888888', 'ayu@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C68', 'Ivan Gunawan', '081799999999', 'ivan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C69', 'Ruben Onsu', '081811111111', 'ruben@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C70', 'Sarwendah', '081822222222', 'sarwendah@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C71', 'Agnez Mo', '081833333333', 'agnez@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C72', 'Anggun C Sasmi', '081844444444', 'anggun@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C73', 'Rich Brian', '081855555555', 'brian@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C74', 'NIKI', '081866666666', 'niki@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C75', 'Warren Hue', '081877777777', 'warren@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C76', 'Stephanie Poetri', '081888888888', 'stephanie@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C77', 'Marion Jola', '081899999999', 'marion@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C78', 'Brisia Jodie', '081911111111', 'brisia@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C79', 'Ghea Indrawari', '081922222222', 'ghea@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C80', 'Ahmad Dhani', '081933333333', 'dhani@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C81', 'Maia Estianty', '081944444444', 'maia@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C82', 'Al Ghazali', '081955555555', 'al@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C83', 'El Rumi', '081966666666', 'el@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C84', 'Dul Jaelani', '081977777777', 'dul@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C85', 'Glenn Alinskie', '081988888888', 'glenn@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C86', 'Chelsea Olivia', '081999999999', 'chelsea.o@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C87', 'Rezky Aditya', '082111111111', 'rezky@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C88', 'Citra Kirana', '082122222222', 'citra@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C89', 'Stefan William', '082133333333', 'stefan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C90', 'Celine Evangelista', '082144444444', 'celine@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C91', 'Natasha Wilona', '082155555555', 'natasha@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C92', 'Verrell Bramasta', '082166666666', 'verrell@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C93', 'Aliando Syarief', '082177777777', 'aliando@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C94', 'Prilly Latuconsina', '082188888888', 'prilly@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C95', 'Maxime Bouttier', '082199999999', 'maxime@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C96', 'Syifa Hadju', '082211112222', 'syifa@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C97', 'Rizky Nazar', '082233334444', 'nazar@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C98', 'Megan Domani', '082255556666', 'megan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C99', 'Bryan Domani', '082277778888', 'bryan@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04'),
('C100', 'Mawar de Jongh', '082299990000', 'mawar.d@email.com', 'cust123', '2026-04-16 09:00:00', 'ADMIN_04', '2026-04-16 09:00:00', 'ADMIN_04');

SELECT * FROM customers
ORDER BY CAST(SUBSTRING(customerID, 2) AS UNSIGNED);

-- 10. Orders
INSERT INTO orders (orderNumber, orderDate, storeNumber, crewID, customerID, promoCode, statusID, totalAmount, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('ORD202604001', '2026-04-16 08:00:00', 'ST001', 'CR002', 'C01', 'NOCODE', 3, 35000, '2026-04-16 08:00:00', 'ADMIN_03', '2026-04-16 08:00:00', 'ADMIN_03'),
('ORD202604002', '2026-04-16 08:05:00', 'ST001', 'CR002', 'C10', 'UPHSTUDENT', 3, 35700, '2026-04-16 08:05:00', 'ADMIN_03', '2026-04-16 08:05:00', 'ADMIN_03'), 
('ORD202604003', '2026-04-16 08:10:00', 'ST001', 'CR003', 'C02', 'PROMO10', 3, 16200, '2026-04-16 08:10:00', 'ADMIN_03', '2026-04-16 08:10:00', 'ADMIN_03'),
('ORD202604004', '2026-04-16 08:15:00', 'ST001', 'CR006', 'C03', 'NOCODE', 3, 42000, '2026-04-16 08:15:00', 'ADMIN_03', '2026-04-16 08:15:00', 'ADMIN_03'),
('ORD202604005', '2026-04-16 08:20:00', 'ST001', 'CR006', 'C04', 'NOCODE', 3, 55000, '2026-04-16 08:20:00', 'ADMIN_03', '2026-04-16 08:20:00', 'ADMIN_03'),
('ORD202604006', '2026-04-16 08:25:00', 'ST001', 'CR010', 'C10', 'TEDX2026', 3, 28000, '2026-04-16 08:25:00', 'ADMIN_03', '2026-04-16 08:25:00', 'ADMIN_03'),
('ORD202604007', '2026-04-16 08:30:00', 'ST001', 'CR014', 'C06', 'NOCODE', 3, 20000, '2026-04-16 08:30:00', 'ADMIN_03', '2026-04-16 08:30:00', 'ADMIN_03'),
('ORD202604008', '2026-04-16 08:35:00', 'ST001', 'CR002', 'C07', 'NOCODE', 3, 35000, '2026-04-16 08:35:00', 'ADMIN_03', '2026-04-16 08:35:00', 'ADMIN_03'),
('ORD202604009', '2026-04-16 08:40:00', 'ST001', 'CR006', 'C08', 'UPHSTUDENT', 3, 46750, '2026-04-16 08:40:00', 'ADMIN_03', '2026-04-16 08:40:00', 'ADMIN_03'),
('ORD202604010', '2026-04-16 08:45:00', 'ST001', 'CR010', 'C09', 'NOCODE', 4, 32000, '2026-04-16 08:45:00', 'ADMIN_03', '2026-04-16 08:45:00', 'ADMIN_03'),
('ORD202604011', '2026-04-16 08:50:00', 'ST001', 'CR014', 'C11', 'NOCODE', 3, 18000, '2026-04-16 08:50:00', 'ADMIN_03', '2026-04-16 08:50:00', 'ADMIN_03'),
('ORD202604012', '2026-04-16 08:55:00', 'ST001', 'CR002', 'C12', 'PROMO10', 3, 31500, '2026-04-16 08:55:00', 'ADMIN_03', '2026-04-16 08:55:00', 'ADMIN_03'),
('ORD202604013', '2026-04-16 09:00:00', 'ST001', 'CR006', 'C10', 'NOCODE', 3, 42000, '2026-04-16 09:00:00', 'ADMIN_03', '2026-04-16 09:00:00', 'ADMIN_03'),
('ORD202604014', '2026-04-16 09:05:00', 'ST001', 'CR010', 'C13', 'NOCODE', 3, 25000, '2026-04-16 09:05:00', 'ADMIN_03', '2026-04-16 09:05:00', 'ADMIN_03'),
('ORD202604015', '2026-04-16 09:10:00', 'ST001', 'CR014', 'C14', 'NOCODE', 3, 55000, '2026-04-16 09:10:00', 'ADMIN_03', '2026-04-16 09:10:00', 'ADMIN_03'),
('ORD202604016', '2026-04-16 09:15:00', 'ST001', 'CR002', 'C15', 'TEDX2026', 3, 25600, '2026-04-16 09:15:00', 'ADMIN_03', '2026-04-16 09:15:00', 'ADMIN_03'),
('ORD202604017', '2026-04-16 09:20:00', 'ST001', 'CR006', 'C10', 'NOCODE', 3, 35000, '2026-04-16 09:20:00', 'ADMIN_03', '2026-04-16 09:20:00', 'ADMIN_03'),
('ORD202604018', '2026-04-16 09:25:00', 'ST001', 'CR010', 'C16', 'UPHSTUDENT', 3, 29750, '2026-04-16 09:25:00', 'ADMIN_03', '2026-04-16 09:25:00', 'ADMIN_03'),
('ORD202604019', '2026-04-16 09:30:00', 'ST001', 'CR014', 'C17', 'NOCODE', 3, 42000, '2026-04-16 09:30:00', 'ADMIN_03', '2026-04-16 09:30:00', 'ADMIN_03'),
('ORD202604020', '2026-04-16 09:35:00', 'ST001', 'CR002', 'C18', 'NOCODE', 3, 20000, '2026-04-16 09:35:00', 'ADMIN_03', '2026-04-16 09:35:00', 'ADMIN_03'),
('ORD202604021', '2026-04-16 09:40:00', 'ST001', 'CR006', 'C19', 'PROMO10', 3, 49500, '2026-04-16 09:40:00', 'ADMIN_03', '2026-04-16 09:40:00', 'ADMIN_03'),
('ORD202604022', '2026-04-16 09:45:00', 'ST001', 'CR010', 'C20', 'NOCODE', 3, 35000, '2026-04-16 09:45:00', 'ADMIN_03', '2026-04-16 09:45:00', 'ADMIN_03'),
('ORD202604023', '2026-04-16 09:50:00', 'ST001', 'CR014', 'C21', 'NOCODE', 1, 32000, '2026-04-16 09:50:00', 'ADMIN_03', '2026-04-16 09:50:00', 'ADMIN_03'),
('ORD202604024', '2026-04-16 09:55:00', 'ST001', 'CR002', 'C10', 'NOCODE', 3, 25000, '2026-04-16 09:55:00', 'ADMIN_03', '2026-04-16 09:55:00', 'ADMIN_03'),
('ORD202604025', '2026-04-16 10:00:00', 'ST001', 'CR006', 'C22', 'NOCODE', 3, 55000, '2026-04-16 10:00:00', 'ADMIN_03', '2026-04-16 10:00:00', 'ADMIN_03'),
('ORD202604026', '2026-04-16 10:05:00', 'ST001', 'CR010', 'C23', 'TEDX2026', 3, 33600, '2026-04-16 10:05:00', 'ADMIN_03', '2026-04-16 10:05:00', 'ADMIN_03'),
('ORD202604027', '2026-04-16 10:10:00', 'ST001', 'CR014', 'C24', 'NOCODE', 3, 18000, '2026-04-16 10:10:00', 'ADMIN_03', '2026-04-16 10:10:00', 'ADMIN_03'),
('ORD202604028', '2026-04-16 10:15:00', 'ST001', 'CR002', 'C25', 'NOCODE', 3, 35000, '2026-04-16 10:15:00', 'ADMIN_03', '2026-04-16 10:15:00', 'ADMIN_03'),
('ORD202604029', '2026-04-16 10:20:00', 'ST001', 'CR006', 'C26', 'UPHSTUDENT', 3, 29750, '2026-04-16 10:20:00', 'ADMIN_03', '2026-04-16 10:20:00', 'ADMIN_03'),
('ORD202604030', '2026-04-16 10:25:00', 'ST001', 'CR010', 'C10', 'NOCODE', 3, 42000, '2026-04-16 10:25:00', 'ADMIN_03', '2026-04-16 10:25:00', 'ADMIN_03'),
('ORD202604031', '2026-04-16 10:30:00', 'ST001', 'CR014', 'C27', 'NOCODE', 3, 20000, '2026-04-16 10:30:00', 'ADMIN_03', '2026-04-16 10:30:00', 'ADMIN_03'),
('ORD202604032', '2026-04-16 10:35:00', 'ST001', 'CR002', 'C28', 'PROMO10', 3, 49500, '2026-04-16 10:35:00', 'ADMIN_03', '2026-04-16 10:35:00', 'ADMIN_03'),
('ORD202604033', '2026-04-16 10:40:00', 'ST001', 'CR006', 'C29', 'NOCODE', 3, 32000, '2026-04-16 10:40:00', 'ADMIN_03', '2026-04-16 10:40:00', 'ADMIN_03'),
('ORD202604034', '2026-04-16 10:45:00', 'ST001', 'CR010', 'C30', 'NOCODE', 2, 55000, '2026-04-16 10:45:00', 'ADMIN_03', '2026-04-16 10:45:00', 'ADMIN_03'),
('ORD202604035', '2026-04-16 10:50:00', 'ST001', 'CR014', 'C31', 'NOCODE', 3, 25000, '2026-04-16 10:50:00', 'ADMIN_03', '2026-04-16 10:50:00', 'ADMIN_03'),
('ORD202604036', '2026-04-16 10:55:00', 'ST001', 'CR002', 'C10', 'TEDX2026', 3, 28000, '2026-04-16 10:55:00', 'ADMIN_03', '2026-04-16 10:55:00', 'ADMIN_03'),
('ORD202604037', '2026-04-16 11:00:00', 'ST001', 'CR006', 'C32', 'NOCODE', 3, 35000, '2026-04-16 11:00:00', 'ADMIN_03', '2026-04-16 11:00:00', 'ADMIN_03'),
('ORD202604038', '2026-04-16 11:05:00', 'ST001', 'CR010', 'C33', 'NOCODE', 3, 42000, '2026-04-16 11:05:00', 'ADMIN_03', '2026-04-16 11:05:00', 'ADMIN_03'),
('ORD202604039', '2026-04-16 11:10:00', 'ST001', 'CR014', 'C34', 'UPHSTUDENT', 3, 15300, '2026-04-16 11:10:00', 'ADMIN_03', '2026-04-16 11:10:00', 'ADMIN_03'),
('ORD202604040', '2026-04-16 11:15:00', 'ST001', 'CR002', 'C35', 'NOCODE', 3, 55000, '2026-04-16 11:15:00', 'ADMIN_03', '2026-04-16 11:15:00', 'ADMIN_03'),
('ORD202604041', '2026-04-16 11:20:00', 'ST001', 'CR006', 'C36', 'NOCODE', 3, 20000, '2026-04-16 11:20:00', 'ADMIN_03', '2026-04-16 11:20:00', 'ADMIN_03'),
('ORD202604042', '2026-04-16 11:25:00', 'ST001', 'CR010', 'C37', 'PROMO10', 3, 28800, '2026-04-16 11:25:00', 'ADMIN_03', '2026-04-16 11:25:00', 'ADMIN_03'),
('ORD202604043', '2026-04-16 11:30:00', 'ST001', 'CR014', 'C10', 'NOCODE', 3, 35000, '2026-04-16 11:30:00', 'ADMIN_03', '2026-04-16 11:30:00', 'ADMIN_03'),
('ORD202604044', '2026-04-16 11:35:00', 'ST001', 'CR002', 'C38', 'NOCODE', 3, 42000, '2026-04-16 11:35:00', 'ADMIN_03', '2026-04-16 11:35:00', 'ADMIN_03'),
('ORD202604045', '2026-04-16 11:40:00', 'ST001', 'CR006', 'C39', 'TEDX2026', 3, 44000, '2026-04-16 11:40:00', 'ADMIN_03', '2026-04-16 11:40:00', 'ADMIN_03'),
('ORD202604046', '2026-04-16 11:45:00', 'ST001', 'CR010', 'C40', 'NOCODE', 4, 25000, '2026-04-16 11:45:00', 'ADMIN_03', '2026-04-16 11:45:00', 'ADMIN_03'),
('ORD202604047', '2026-04-16 11:50:00', 'ST001', 'CR014', 'C41', 'NOCODE', 3, 35000, '2026-04-16 11:50:00', 'ADMIN_03', '2026-04-16 11:50:00', 'ADMIN_03'),
('ORD202604048', '2026-04-16 11:55:00', 'ST001', 'CR002', 'C42', 'UPHSTUDENT', 3, 46750, '2026-04-16 11:55:00', 'ADMIN_03', '2026-04-16 11:55:00', 'ADMIN_03'),
('ORD202604049', '2026-04-16 12:00:00', 'ST001', 'CR006', 'C43', 'NOCODE', 3, 18000, '2026-04-16 12:00:00', 'ADMIN_03', '2026-04-16 12:00:00', 'ADMIN_03'),
('ORD202604050', '2026-04-16 12:05:00', 'ST001', 'CR010', 'C10', 'NOCODE', 3, 20000, '2026-04-16 12:05:00', 'ADMIN_03', '2026-04-16 12:05:00', 'ADMIN_03'),
('ORD202604051', '2026-04-16 12:10:00', 'ST001', 'CR014', 'C44', 'PROMO10', 3, 31500, '2026-04-16 12:10:00', 'ADMIN_03', '2026-04-16 12:10:00', 'ADMIN_03'),
('ORD202604052', '2026-04-16 12:15:00', 'ST001', 'CR002', 'C45', 'NOCODE', 3, 35000, '2026-04-16 12:15:00', 'ADMIN_03', '2026-04-16 12:15:00', 'ADMIN_03'),
('ORD202604053', '2026-04-16 12:20:00', 'ST001', 'CR006', 'C46', 'NOCODE', 3, 42000, '2026-04-16 12:20:00', 'ADMIN_03', '2026-04-16 12:20:00', 'ADMIN_03'),
('ORD202604054', '2026-04-16 12:25:00', 'ST001', 'CR010', 'C47', 'TEDX2026', 3, 25600, '2026-04-16 12:25:00', 'ADMIN_03', '2026-04-16 12:25:00', 'ADMIN_03'),
('ORD202604055', '2026-04-16 12:30:00', 'ST001', 'CR014', 'C48', 'NOCODE', 3, 55000, '2026-04-16 12:30:00', 'ADMIN_03', '2026-04-16 12:30:00', 'ADMIN_03'),
('ORD202604056', '2026-04-16 12:35:00', 'ST001', 'CR002', 'C10', 'NOCODE', 3, 25000, '2026-04-16 12:35:00', 'ADMIN_03', '2026-04-16 12:35:00', 'ADMIN_03'),
('ORD202604057', '2026-04-16 12:40:00', 'ST001', 'CR006', 'C49', 'UPHSTUDENT', 3, 29750, '2026-04-16 12:40:00', 'ADMIN_03', '2026-04-16 12:40:00', 'ADMIN_03'),
('ORD202604058', '2026-04-16 12:45:00', 'ST001', 'CR010', 'C50', 'NOCODE', 2, 42000, '2026-04-16 12:45:00', 'ADMIN_03', '2026-04-16 12:45:00', 'ADMIN_03'),
('ORD202604059', '2026-04-16 12:50:00', 'ST001', 'CR014', 'C51', 'NOCODE', 3, 18000, '2026-04-16 12:50:00', 'ADMIN_03', '2026-04-16 12:50:00', 'ADMIN_03'),
('ORD202604060', '2026-04-16 12:55:00', 'ST001', 'CR002', 'C52', 'PROMO10', 3, 18000, '2026-04-16 12:55:00', 'ADMIN_03', '2026-04-16 12:55:00', 'ADMIN_03'),
('ORD202604061', '2026-04-16 13:00:00', 'ST001', 'CR006', 'C53', 'NOCODE', 3, 35000, '2026-04-16 13:00:00', 'ADMIN_03', '2026-04-16 13:00:00', 'ADMIN_03'),
('ORD202604062', '2026-04-16 13:05:00', 'ST001', 'CR010', 'C10', 'NOCODE', 3, 55000, '2026-04-16 13:05:00', 'ADMIN_03', '2026-04-16 13:05:00', 'ADMIN_03'),
('ORD202604063', '2026-04-16 13:10:00', 'ST001', 'CR014', 'C54', 'TEDX2026', 3, 33600, '2026-04-16 13:10:00', 'ADMIN_03', '2026-04-16 13:10:00', 'ADMIN_03'),
('ORD202604064', '2026-04-16 13:15:00', 'ST001', 'CR002', 'C55', 'NOCODE', 3, 20000, '2026-04-16 13:15:00', 'ADMIN_03', '2026-04-16 13:15:00', 'ADMIN_03'),
('ORD202604065', '2026-04-16 13:20:00', 'ST001', 'CR006', 'C56', 'UPHSTUDENT', 3, 46750, '2026-04-16 13:20:00', 'ADMIN_03', '2026-04-16 13:20:00', 'ADMIN_03'),
('ORD202604066', '2026-04-16 13:25:00', 'ST001', 'CR010', 'C57', 'NOCODE', 3, 35000, '2026-04-16 13:25:00', 'ADMIN_03', '2026-04-16 13:25:00', 'ADMIN_03'),
('ORD202604067', '2026-04-16 13:30:00', 'ST001', 'CR014', 'C58', 'NOCODE', 4, 42000, '2026-04-16 13:30:00', 'ADMIN_03', '2026-04-16 13:30:00', 'ADMIN_03'),
('ORD202604068', '2026-04-16 13:35:00', 'ST001', 'CR002', 'C10', 'NOCODE', 3, 25000, '2026-04-16 13:35:00', 'ADMIN_03', '2026-04-16 13:35:00', 'ADMIN_03'),
('ORD202604069', '2026-04-16 13:40:00', 'ST001', 'CR006', 'C59', 'PROMO10', 3, 31500, '2026-04-16 13:40:00', 'ADMIN_03', '2026-04-16 13:40:00', 'ADMIN_03'),
('ORD202604070', '2026-04-16 13:45:00', 'ST001', 'CR010', 'C60', 'NOCODE', 3, 18000, '2026-04-16 13:45:00', 'ADMIN_03', '2026-04-16 13:45:00', 'ADMIN_03'),
('ORD202604071', '2026-04-16 13:50:00', 'ST001', 'CR014', 'C61', 'NOCODE', 3, 55000, '2026-04-16 13:50:00', 'ADMIN_03', '2026-04-16 13:50:00', 'ADMIN_03'),
('ORD202604072', '2026-04-16 13:55:00', 'ST001', 'CR002', 'C62', 'TEDX2026', 3, 28000, '2026-04-16 13:55:00', 'ADMIN_03', '2026-04-16 13:55:00', 'ADMIN_03'),
('ORD202604073', '2026-04-16 14:00:00', 'ST001', 'CR006', 'C63', 'NOCODE', 3, 35000, '2026-04-16 14:00:00', 'ADMIN_03', '2026-04-16 14:00:00', 'ADMIN_03'),
('ORD202604074', '2026-04-16 14:05:00', 'ST001', 'CR010', 'C10', 'NOCODE', 3, 42000, '2026-04-16 14:05:00', 'ADMIN_03', '2026-04-16 14:05:00', 'ADMIN_03'),
('ORD202604075', '2026-04-16 14:10:00', 'ST001', 'CR014', 'C64', 'UPHSTUDENT', 3, 29750, '2026-04-16 14:10:00', 'ADMIN_03', '2026-04-16 14:10:00', 'ADMIN_03'),
('ORD202604076', '2026-04-16 14:15:00', 'ST001', 'CR002', 'C65', 'NOCODE', 1, 20000, '2026-04-16 14:15:00', 'ADMIN_03', '2026-04-16 14:15:00', 'ADMIN_03'),
('ORD202604077', '2026-04-16 14:20:00', 'ST001', 'CR006', 'C66', 'NOCODE', 3, 25000, '2026-04-16 14:20:00', 'ADMIN_03', '2026-04-16 14:20:00', 'ADMIN_03'),
('ORD202604078', '2026-04-16 14:25:00', 'ST001', 'CR010', 'C67', 'PROMO10', 3, 49500, '2026-04-16 14:25:00', 'ADMIN_03', '2026-04-16 14:25:00', 'ADMIN_03'),
('ORD202604079', '2026-04-16 14:30:00', 'ST001', 'CR014', 'C68', 'NOCODE', 3, 35000, '2026-04-16 14:30:00', 'ADMIN_03', '2026-04-16 14:30:00', 'ADMIN_03'),
('ORD202604080', '2026-04-16 14:35:00', 'ST001', 'CR002', 'C10', 'NOCODE', 3, 18000, '2026-04-16 14:35:00', 'ADMIN_03', '2026-04-16 14:35:00', 'ADMIN_03'),
('ORD202604081', '2026-04-16 14:40:00', 'ST001', 'CR006', 'C69', 'TEDX2026', 3, 25600, '2026-04-16 14:40:00', 'ADMIN_03', '2026-04-16 14:40:00', 'ADMIN_03'),
('ORD202604082', '2026-04-16 14:45:00', 'ST001', 'CR010', 'C70', 'NOCODE', 3, 42000, '2026-04-16 14:45:00', 'ADMIN_03', '2026-04-16 14:45:00', 'ADMIN_03'),
('ORD202604083', '2026-04-16 14:50:00', 'ST001', 'CR014', 'C71', 'NOCODE', 3, 55000, '2026-04-16 14:50:00', 'ADMIN_03', '2026-04-16 14:50:00', 'ADMIN_03'),
('ORD202604084', '2026-04-16 14:55:00', 'ST001', 'CR002', 'C72', 'UPHSTUDENT', 3, 17000, '2026-04-16 14:55:00', 'ADMIN_03', '2026-04-16 14:55:00', 'ADMIN_03'),
('ORD202604085', '2026-04-16 15:00:00', 'ST001', 'CR006', 'C73', 'NOCODE', 3, 35000, '2026-04-16 15:00:00', 'ADMIN_03', '2026-04-16 15:00:00', 'ADMIN_03'),
('ORD202604086', '2026-04-16 15:05:00', 'ST001', 'CR010', 'C74', 'NOCODE', 3, 25000, '2026-04-16 15:05:00', 'ADMIN_03', '2026-04-16 15:05:00', 'ADMIN_03'),
('ORD202604087', '2026-04-16 15:10:00', 'ST001', 'CR014', 'C10', 'PROMO10', 3, 37800, '2026-04-16 15:10:00', 'ADMIN_03', '2026-04-16 15:10:00', 'ADMIN_03'),
('ORD202604088', '2026-04-16 15:15:00', 'ST001', 'CR002', 'C75', 'NOCODE', 3, 20000, '2026-04-16 15:15:00', 'ADMIN_03', '2026-04-16 15:15:00', 'ADMIN_03'),
('ORD202604089', '2026-04-16 15:20:00', 'ST001', 'CR006', 'C76', 'NOCODE', 3, 42000, '2026-04-16 15:20:00', 'ADMIN_03', '2026-04-16 15:20:00', 'ADMIN_03'),
('ORD202604090', '2026-04-16 15:25:00', 'ST001', 'CR010', 'C77', 'TEDX2026', 3, 44000, '2026-04-16 15:25:00', 'ADMIN_03', '2026-04-16 15:25:00', 'ADMIN_03'),
('ORD202604091', '2026-04-16 15:30:00', 'ST001', 'CR014', 'C78', 'NOCODE', 3, 35000, '2026-04-16 15:30:00', 'ADMIN_03', '2026-04-16 15:30:00', 'ADMIN_03'),
('ORD202604092', '2026-04-16 15:35:00', 'ST001', 'CR002', 'C79', 'NOCODE', 2, 18000, '2026-04-16 15:35:00', 'ADMIN_03', '2026-04-16 15:35:00', 'ADMIN_03'),
('ORD202604093', '2026-04-16 15:40:00', 'ST001', 'CR006', 'C10', 'UPHSTUDENT', 3, 21250, '2026-04-16 15:40:00', 'ADMIN_03', '2026-04-16 15:40:00', 'ADMIN_03'),
('ORD202604094', '2026-04-16 15:45:00', 'ST001', 'CR010', 'C80', 'NOCODE', 3, 55000, '2026-04-16 15:45:00', 'ADMIN_03', '2026-04-16 15:45:00', 'ADMIN_03'),
('ORD202604095', '2026-04-16 15:50:00', 'ST001', 'CR014', 'C81', 'NOCODE', 3, 42000, '2026-04-16 15:50:00', 'ADMIN_03', '2026-04-16 15:50:00', 'ADMIN_03'),
('ORD202604096', '2026-04-16 15:55:00', 'ST001', 'CR002', 'C82', 'PROMO10', 3, 18000, '2026-04-16 15:55:00', 'ADMIN_03', '2026-04-16 15:55:00', 'ADMIN_03'),
('ORD202604097', '2026-04-16 16:00:00', 'ST001', 'CR006', 'C83', 'NOCODE', 3, 25000, '2026-04-16 16:00:00', 'ADMIN_03', '2026-04-16 16:00:00', 'ADMIN_03'),
('ORD202604098', '2026-04-16 16:05:00', 'ST001', 'CR010', 'C84', 'NOCODE', 3, 35000, '2026-04-16 16:05:00', 'ADMIN_03', '2026-04-16 16:05:00', 'ADMIN_03'),
('ORD202604099', '2026-04-16 16:10:00', 'ST001', 'CR014', 'C10', 'TEDX2026', 3, 16000, '2026-04-16 16:10:00', 'ADMIN_03', '2026-04-16 16:10:00', 'ADMIN_03'),
('ORD202604100', '2026-04-16 16:15:00', 'ST001', 'CR002', 'C85', 'NOCODE', 3, 42000, '2026-04-16 16:15:00', 'ADMIN_03', '2026-04-16 16:15:00', 'ADMIN_03');

-- 11. OrderItems
INSERT INTO orderItems (orderNumber, menuID, quantityItem, subtotal, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('ORD202604001', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604002', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604003', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604004', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604005', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604006', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604007', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604008', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604009', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604010', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604011', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604012', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604013', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604014', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604015', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604016', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604017', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604018', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604019', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604020', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604021', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604022', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604023', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604024', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604025', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604026', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604027', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604028', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604029', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604030', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604031', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604032', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604033', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604034', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604035', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604036', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604037', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604038', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604039', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604040', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604041', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604042', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604043', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604044', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604045', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604046', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604047', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604048', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604049', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604050', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604051', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604052', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604053', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604054', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604055', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604056', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604057', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604058', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604059', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604060', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604061', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604062', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604063', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604064', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604065', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604066', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604067', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604068', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604069', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604070', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604071', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604072', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604073', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604074', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604075', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604076', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604077', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604078', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604079', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604080', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604081', 'MN04', 1, 32000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Chicken Burger
('ORD202604082', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604083', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604084', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604085', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604086', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604087', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604088', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604089', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604090', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604091', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604092', 'MN05', 1, 18000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Fried Chicken
('ORD202604093', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604094', 'MN03', 1, 55000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Double Beef
('ORD202604095', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Cheese Burger
('ORD202604096', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604097', 'MN07', 1, 25000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Nasi Ayam
('ORD202604098', 'MN01', 1, 35000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- Classic Burger
('ORD202604099', 'MN06', 1, 20000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'), -- French Fries L
('ORD202604100', 'MN02', 1, 42000, '2026-04-16 16:30:00', 'ADMIN_03', '2026-04-16 16:30:00', 'ADMIN_03'); -- Cheese Burger

-- 12. Supplier
INSERT INTO suppliers (supplierID, supplierName, contactPerson, supplierAddress, createdAt, createdBy, updatedAt, updatedBy) VALUES
('SUP01', 'PT Ayam Bakti Jaya', '081299887766', 'Jl. Industri No. 12, Cikarang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'), 
('SUP02', 'CV Berkah Tani Bogor', '081222334455', 'Kawasan Agribisnis No. 5, Bogor', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'), 
('SUP03', 'Roti Jaya Perkasa', '081266778899', 'Jl. Panjang No. 45, Jakarta Barat', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'), 
('SUP04', 'Lippo Fresh Mart', '081254600011', 'Lippo Karawaci, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'), 
('SUP05', 'UD Sumber Rasa Jakarta', '081211223344', 'Pasar Induk Kramat Jati, Jakarta Timur', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'), 
('SUP06', 'PT Pangan Mandiri', '081244556677', 'Kawasan Industri Pulogadung', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP07', 'PT Sayur Segar Sentosa', 'Ahmad', 'Jl. Raya Serpong No 11, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP08', 'CV Kemasan Ramah Lingkungan', 'Cheryl', 'Kawasan Industri Jatake, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP09', 'UD Daging Sapi Premium', 'Candra', 'Jl. Sudirman No 4, Jakarta Pusat', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP10', 'PT Bumbu Masak Nusantara', 'Deni', 'Pasar Induk Cikokol, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP11', 'CV Minyak Goreng Murni', 'Eka', 'Jl. Daan Mogot Km 15, Jakarta Barat', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP12', 'UD Plastik Bening Abadi', 'Fajar', 'Kawasan Balaraja Timur, Banten', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP13', 'PT Es Kristal Dingin', 'Gita', 'Jl. Imam Bonjol No 22, Karawaci', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP14', 'CV Susu Segar Lembang', 'Hadi', 'Jl. Raya Lembang No 88, Bandung', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP15', 'UD Ayam Roaster Jkt', 'Indra', 'Jl. Senopati No 14, Jakarta Selatan', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP16', 'PT Teh Wangi Melati', 'Joko', 'Jl. Merdeka No 9, Bogor', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP17', 'CV Beras Pulen Makmur', 'Kartika', 'Pasar Induk Cipinang, Jakarta Timur', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP18', 'UD Ayam Potong Super', 'Lukman', 'Kawasan Pasar Kemis, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP19', 'PT Roti Jaya', 'Maya', 'Jl. Kapuk Raya No 45, Jakarta Utara', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP20', 'CV Gula Manis Terang', 'Niko', 'Jl. Gatot Subroto, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP21', 'UD Garam Laut Bersih', 'Oki', 'Kawasan Pelabuhan Sunda Kelapa', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP22', 'PT Bawang Merah Probolinggo', 'Putri', 'Pasar Induk Kramat Jati, Jakarta', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP23', 'CV Bawang Putih Impor', 'Qori', 'Kawasan Berikat Nusantara, Cakung', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP24', 'UD Cabai Pedas Mantap', 'Rizki', 'Pasar Induk Tanah Tinggi, Tangerang', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02'),
('SUP25', 'PT Tomat Merah Merona', 'Sari', 'Kawasan Puncak, Cisarua', '2026-04-16 08:30:00', 'ADMIN_02', '2026-04-16 08:30:00', 'ADMIN_02');

-- 13. Supplier Purchases
INSERT INTO supplierPurchases (purchaseID, purchaseDate, storeNumber, supplierID, totalCost, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('PUR202604001', '2026-04-01 09:00:00', 'ST001', 'SUP01', 2850000, '2026-04-01 09:00:00', 'ADMIN_02', '2026-04-01 09:00:00', 'ADMIN_02'),
('PUR202604002', '2026-04-01 10:15:00', 'ST001', 'SUP02', 440000, '2026-04-01 10:15:00', 'ADMIN_02', '2026-04-01 10:15:00', 'ADMIN_02'),
('PUR202604003', '2026-04-01 11:30:00', 'ST001', 'SUP03', 4300000, '2026-04-01 11:30:00', 'ADMIN_02', '2026-04-01 11:30:00', 'ADMIN_02'),
('PUR202604004', '2026-04-01 13:45:00', 'ST001', 'SUP04', 920000, '2026-04-01 13:45:00', 'ADMIN_02', '2026-04-01 13:45:00', 'ADMIN_02'),
('PUR202604005', '2026-04-01 15:00:00', 'ST001', 'SUP05', 150000, '2026-04-01 15:00:00', 'ADMIN_02', '2026-04-01 15:00:00', 'ADMIN_02'),
('PUR202604006', '2026-04-02 09:00:00', 'ST001', 'SUP06', 2500000, '2026-04-02 09:00:00', 'ADMIN_02', '2026-04-02 09:00:00', 'ADMIN_02'),
('PUR202604007', '2026-04-02 10:00:00', 'ST001', 'SUP07', 1200000, '2026-04-02 10:00:00', 'ADMIN_02', '2026-04-02 10:00:00', 'ADMIN_02'),
('PUR202604008', '2026-04-02 11:00:00', 'ST001', 'SUP08', 850000, '2026-04-02 11:00:00', 'ADMIN_02', '2026-04-02 11:00:00', 'ADMIN_02'),
('PUR202604009', '2026-04-02 13:00:00', 'ST001', 'SUP09', 5400000, '2026-04-02 13:00:00', 'ADMIN_02', '2026-04-02 13:00:00', 'ADMIN_02'),
('PUR202604010', '2026-04-02 14:30:00', 'ST001', 'SUP10', 300000, '2026-04-02 14:30:00', 'ADMIN_02', '2026-04-02 14:30:00', 'ADMIN_02'),
('PUR202604011', '2026-04-03 09:15:00', 'ST001', 'SUP11', 1100000, '2026-04-03 09:15:00', 'ADMIN_02', '2026-04-03 09:15:00', 'ADMIN_02'),
('PUR202604012', '2026-04-03 10:45:00', 'ST001', 'SUP12', 450000, '2026-04-03 10:45:00', 'ADMIN_02', '2026-04-03 10:45:00', 'ADMIN_02'),
('PUR202604013', '2026-04-03 13:30:00', 'ST001', 'SUP13', 600000, '2026-04-03 13:30:00', 'ADMIN_02', '2026-04-03 13:30:00', 'ADMIN_02'),
('PUR202604014', '2026-04-03 15:00:00', 'ST001', 'SUP14', 1800000, '2026-04-03 15:00:00', 'ADMIN_02', '2026-04-03 15:00:00', 'ADMIN_02'),
('PUR202604015', '2026-04-03 16:30:00', 'ST001', 'SUP15', 3200000, '2026-04-03 16:30:00', 'ADMIN_02', '2026-04-03 16:30:00', 'ADMIN_02'),
('PUR202604016', '2026-04-04 09:00:00', 'ST001', 'SUP16', 750000, '2026-04-04 09:00:00', 'ADMIN_02', '2026-04-04 09:00:00', 'ADMIN_02'),
('PUR202604017', '2026-04-04 10:00:00', 'ST001', 'SUP17', 2400000, '2026-04-04 10:00:00', 'ADMIN_02', '2026-04-04 10:00:00', 'ADMIN_02'),
('PUR202604018', '2026-04-04 11:00:00', 'ST001', 'SUP18', 4100000, '2026-04-04 11:00:00', 'ADMIN_02', '2026-04-04 11:00:00', 'ADMIN_02'),
('PUR202604019', '2026-04-04 13:00:00', 'ST001', 'SUP19', 1500000, '2026-04-04 13:00:00', 'ADMIN_02', '2026-04-04 13:00:00', 'ADMIN_02'),
('PUR202604020', '2026-04-04 14:30:00', 'ST001', 'SUP20', 950000, '2026-04-04 14:30:00', 'ADMIN_02', '2026-04-04 14:30:00', 'ADMIN_02'),
('PUR202604021', '2026-04-05 09:00:00', 'ST001', 'SUP21', 120000, '2026-04-05 09:00:00', 'ADMIN_02', '2026-04-05 09:00:00', 'ADMIN_02'),
('PUR202604022', '2026-04-05 10:15:00', 'ST001', 'SUP22', 800000, '2026-04-05 10:15:00', 'ADMIN_02', '2026-04-05 10:15:00', 'ADMIN_02'),
('PUR202604023', '2026-04-05 11:30:00', 'ST001', 'SUP23', 650000, '2026-04-05 11:30:00', 'ADMIN_02', '2026-04-05 11:30:00', 'ADMIN_02'),
('PUR202604024', '2026-04-05 13:45:00', 'ST001', 'SUP24', 400000, '2026-04-05 13:45:00', 'ADMIN_02', '2026-04-05 13:45:00', 'ADMIN_02'),
('PUR202604025', '2026-04-05 15:00:00', 'ST001', 'SUP25', 1300000, '2026-04-05 15:00:00', 'ADMIN_02', '2026-04-05 15:00:00', 'ADMIN_02'),
('PUR202604026', '2026-04-06 09:00:00', 'ST001', 'SUP01', 2100000, '2026-04-06 09:00:00', 'ADMIN_02', '2026-04-06 09:00:00', 'ADMIN_02'),
('PUR202604027', '2026-04-06 10:15:00', 'ST001', 'SUP02', 380000, '2026-04-06 10:15:00', 'ADMIN_02', '2026-04-06 10:15:00', 'ADMIN_02'),
('PUR202604028', '2026-04-06 11:30:00', 'ST001', 'SUP03', 3900000, '2026-04-06 11:30:00', 'ADMIN_02', '2026-04-06 11:30:00', 'ADMIN_02'),
('PUR202604029', '2026-04-06 13:45:00', 'ST001', 'SUP04', 1100000, '2026-04-06 13:45:00', 'ADMIN_02', '2026-04-06 13:45:00', 'ADMIN_02'),
('PUR202604030', '2026-04-06 15:00:00', 'ST001', 'SUP05', 200000, '2026-04-06 15:00:00', 'ADMIN_02', '2026-04-06 15:00:00', 'ADMIN_02'),
('PUR202604031', '2026-04-07 09:00:00', 'ST001', 'SUP06', 2200000, '2026-04-07 09:00:00', 'ADMIN_02', '2026-04-07 09:00:00', 'ADMIN_02'),
('PUR202604032', '2026-04-07 10:00:00', 'ST001', 'SUP07', 1000000, '2026-04-07 10:00:00', 'ADMIN_02', '2026-04-07 10:00:00', 'ADMIN_02'),
('PUR202604033', '2026-04-07 11:00:00', 'ST001', 'SUP08', 920000, '2026-04-07 11:00:00', 'ADMIN_02', '2026-04-07 11:00:00', 'ADMIN_02'),
('PUR202604034', '2026-04-07 13:00:00', 'ST001', 'SUP09', 4800000, '2026-04-07 13:00:00', 'ADMIN_02', '2026-04-07 13:00:00', 'ADMIN_02'),
('PUR202604035', '2026-04-07 14:30:00', 'ST001', 'SUP10', 450000, '2026-04-07 14:30:00', 'ADMIN_02', '2026-04-07 14:30:00', 'ADMIN_02'),
('PUR202604036', '2026-04-08 09:15:00', 'ST001', 'SUP11', 980000, '2026-04-08 09:15:00', 'ADMIN_02', '2026-04-08 09:15:00', 'ADMIN_02'),
('PUR202604037', '2026-04-08 10:45:00', 'ST001', 'SUP12', 520000, '2026-04-08 10:45:00', 'ADMIN_02', '2026-04-08 10:45:00', 'ADMIN_02'),
('PUR202604038', '2026-04-08 13:30:00', 'ST001', 'SUP13', 700000, '2026-04-08 13:30:00', 'ADMIN_02', '2026-04-08 13:30:00', 'ADMIN_02'),
('PUR202604039', '2026-04-08 15:00:00', 'ST001', 'SUP14', 1950000, '2026-04-08 15:00:00', 'ADMIN_02', '2026-04-08 15:00:00', 'ADMIN_02'),
('PUR202604040', '2026-04-08 16:30:00', 'ST001', 'SUP15', 2900000, '2026-04-08 16:30:00', 'ADMIN_02', '2026-04-08 16:30:00', 'ADMIN_02'),
('PUR202604041', '2026-04-09 09:00:00', 'ST001', 'SUP16', 820000, '2026-04-09 09:00:00', 'ADMIN_02', '2026-04-09 09:00:00', 'ADMIN_02'),
('PUR202604042', '2026-04-09 10:00:00', 'ST001', 'SUP17', 2100000, '2026-04-09 10:00:00', 'ADMIN_02', '2026-04-09 10:00:00', 'ADMIN_02'),
('PUR202604043', '2026-04-09 11:00:00', 'ST001', 'SUP18', 3800000, '2026-04-09 11:00:00', 'ADMIN_02', '2026-04-09 11:00:00', 'ADMIN_02'),
('PUR202604044', '2026-04-09 13:00:00', 'ST001', 'SUP19', 1250000, '2026-04-09 13:00:00', 'ADMIN_02', '2026-04-09 13:00:00', 'ADMIN_02'),
('PUR202604045', '2026-04-09 14:30:00', 'ST001', 'SUP20', 880000, '2026-04-09 14:30:00', 'ADMIN_02', '2026-04-09 14:30:00', 'ADMIN_02'),
('PUR202604046', '2026-04-10 09:00:00', 'ST001', 'SUP21', 145000, '2026-04-10 09:00:00', 'ADMIN_02', '2026-04-10 09:00:00', 'ADMIN_02'),
('PUR202604047', '2026-04-10 10:15:00', 'ST001', 'SUP22', 720000, '2026-04-10 10:15:00', 'ADMIN_02', '2026-04-10 10:15:00', 'ADMIN_02'),
('PUR202604048', '2026-04-10 11:30:00', 'ST001', 'SUP23', 590000, '2026-04-10 11:30:00', 'ADMIN_02', '2026-04-10 11:30:00', 'ADMIN_02'),
('PUR202604049', '2026-04-10 13:45:00', 'ST001', 'SUP24', 480000, '2026-04-10 13:45:00', 'ADMIN_02', '2026-04-10 13:45:00', 'ADMIN_02'),
('PUR202604050', '2026-04-10 15:00:00', 'ST001', 'SUP25', 1450000, '2026-04-10 15:00:00', 'ADMIN_02', '2026-04-10 15:00:00', 'ADMIN_02'),
('PUR202604051', '2026-04-11 09:00:00', 'ST001', 'SUP01', 2450000, '2026-04-11 09:00:00', 'ADMIN_02', '2026-04-11 09:00:00', 'ADMIN_02'),
('PUR202604052', '2026-04-11 10:15:00', 'ST001', 'SUP02', 410000, '2026-04-11 10:15:00', 'ADMIN_02', '2026-04-11 10:15:00', 'ADMIN_02'),
('PUR202604053', '2026-04-11 11:30:00', 'ST001', 'SUP03', 4100000, '2026-04-11 11:30:00', 'ADMIN_02', '2026-04-11 11:30:00', 'ADMIN_02'),
('PUR202604054', '2026-04-11 13:45:00', 'ST001', 'SUP04', 1050000, '2026-04-11 13:45:00', 'ADMIN_02', '2026-04-11 13:45:00', 'ADMIN_02'),
('PUR202604055', '2026-04-11 15:00:00', 'ST001', 'SUP05', 180000, '2026-04-11 15:00:00', 'ADMIN_02', '2026-04-11 15:00:00', 'ADMIN_02'),
('PUR202604056', '2026-04-12 09:00:00', 'ST001', 'SUP06', 2350000, '2026-04-12 09:00:00', 'ADMIN_02', '2026-04-12 09:00:00', 'ADMIN_02'),
('PUR202604057', '2026-04-12 10:00:00', 'ST001', 'SUP07', 1150000, '2026-04-12 10:00:00', 'ADMIN_02', '2026-04-12 10:00:00', 'ADMIN_02'),
('PUR202604058', '2026-04-12 11:00:00', 'ST001', 'SUP08', 890000, '2026-04-12 11:00:00', 'ADMIN_02', '2026-04-12 11:00:00', 'ADMIN_02'),
('PUR202604059', '2026-04-12 13:00:00', 'ST001', 'SUP09', 5100000, '2026-04-12 13:00:00', 'ADMIN_02', '2026-04-12 13:00:00', 'ADMIN_02'),
('PUR202604060', '2026-04-12 14:30:00', 'ST001', 'SUP10', 420000, '2026-04-12 14:30:00', 'ADMIN_02', '2026-04-12 14:30:00', 'ADMIN_02'),
('PUR202604061', '2026-04-13 09:15:00', 'ST001', 'SUP11', 1050000, '2026-04-13 09:15:00', 'ADMIN_02', '2026-04-13 09:15:00', 'ADMIN_02'),
('PUR202604062', '2026-04-13 10:45:00', 'ST001', 'SUP12', 480000, '2026-04-13 10:45:00', 'ADMIN_02', '2026-04-13 10:45:00', 'ADMIN_02'),
('PUR202604063', '2026-04-13 13:30:00', 'ST001', 'SUP13', 680000, '2026-04-13 13:30:00', 'ADMIN_02', '2026-04-13 13:30:00', 'ADMIN_02'),
('PUR202604064', '2026-04-13 15:00:00', 'ST001', 'SUP14', 1850000, '2026-04-13 15:00:00', 'ADMIN_02', '2026-04-13 15:00:00', 'ADMIN_02'),
('PUR202604065', '2026-04-13 16:30:00', 'ST001', 'SUP15', 3100000, '2026-04-13 16:30:00', 'ADMIN_02', '2026-04-13 16:30:00', 'ADMIN_02'),
('PUR202604066', '2026-04-14 09:00:00', 'ST001', 'SUP16', 790000, '2026-04-14 09:00:00', 'ADMIN_02', '2026-04-14 09:00:00', 'ADMIN_02'),
('PUR202604067', '2026-04-14 10:00:00', 'ST001', 'SUP17', 2250000, '2026-04-14 10:00:00', 'ADMIN_02', '2026-04-14 10:00:00', 'ADMIN_02'),
('PUR202604068', '2026-04-14 11:00:00', 'ST001', 'SUP18', 3950000, '2026-04-14 11:00:00', 'ADMIN_02', '2026-04-14 11:00:00', 'ADMIN_02'),
('PUR202604069', '2026-04-14 13:00:00', 'ST001', 'SUP19', 1400000, '2026-04-14 13:00:00', 'ADMIN_02', '2026-04-14 13:00:00', 'ADMIN_02'),
('PUR202604070', '2026-04-14 14:30:00', 'ST001', 'SUP20', 920000, '2026-04-14 14:30:00', 'ADMIN_02', '2026-04-14 14:30:00', 'ADMIN_02'),
('PUR202604071', '2026-04-15 09:00:00', 'ST001', 'SUP21', 135000, '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'),
('PUR202604072', '2026-04-15 10:15:00', 'ST001', 'SUP22', 780000, '2026-04-15 10:15:00', 'ADMIN_02', '2026-04-15 10:15:00', 'ADMIN_02'),
('PUR202604073', '2026-04-15 11:30:00', 'ST001', 'SUP23', 620000, '2026-04-15 11:30:00', 'ADMIN_02', '2026-04-15 11:30:00', 'ADMIN_02'),
('PUR202604074', '2026-04-15 13:45:00', 'ST001', 'SUP24', 450000, '2026-04-15 13:45:00', 'ADMIN_02', '2026-04-15 13:45:00', 'ADMIN_02'),
('PUR202604075', '2026-04-15 15:00:00', 'ST001', 'SUP25', 1350000, '2026-04-15 15:00:00', 'ADMIN_02', '2026-04-15 15:00:00', 'ADMIN_02'),
('PUR202604076', '2026-04-16 09:00:00', 'ST001', 'SUP01', 2250000, '2026-04-16 09:00:00', 'ADMIN_02', '2026-04-16 09:00:00', 'ADMIN_02'),
('PUR202604077', '2026-04-16 10:15:00', 'ST001', 'SUP02', 390000, '2026-04-16 10:15:00', 'ADMIN_02', '2026-04-16 10:15:00', 'ADMIN_02'),
('PUR202604078', '2026-04-16 11:30:00', 'ST001', 'SUP03', 4000000, '2026-04-16 11:30:00', 'ADMIN_02', '2026-04-16 11:30:00', 'ADMIN_02'),
('PUR202604079', '2026-04-16 13:45:00', 'ST001', 'SUP04', 980000, '2026-04-16 13:45:00', 'ADMIN_02', '2026-04-16 13:45:00', 'ADMIN_02'),
('PUR202604080', '2026-04-16 15:00:00', 'ST001', 'SUP05', 160000, '2026-04-16 15:00:00', 'ADMIN_02', '2026-04-16 15:00:00', 'ADMIN_02'),
('PUR202604081', '2026-04-17 09:00:00', 'ST001', 'SUP06', 2400000, '2026-04-17 09:00:00', 'ADMIN_02', '2026-04-17 09:00:00', 'ADMIN_02'),
('PUR202604082', '2026-04-17 10:00:00', 'ST001', 'SUP07', 1050000, '2026-04-17 10:00:00', 'ADMIN_02', '2026-04-17 10:00:00', 'ADMIN_02'),
('PUR202604083', '2026-04-17 11:00:00', 'ST001', 'SUP08', 910000, '2026-04-17 11:00:00', 'ADMIN_02', '2026-04-17 11:00:00', 'ADMIN_02'),
('PUR202604084', '2026-04-17 13:00:00', 'ST001', 'SUP09', 4950000, '2026-04-17 13:00:00', 'ADMIN_02', '2026-04-17 13:00:00', 'ADMIN_02'),
('PUR202604085', '2026-04-17 14:30:00', 'ST001', 'SUP10', 380000, '2026-04-17 14:30:00', 'ADMIN_02', '2026-04-17 14:30:00', 'ADMIN_02'),
('PUR202604086', '2026-04-18 09:15:00', 'ST001', 'SUP11', 1000000, '2026-04-18 09:15:00', 'ADMIN_02', '2026-04-18 09:15:00', 'ADMIN_02'),
('PUR202604087', '2026-04-18 10:45:00', 'ST001', 'SUP12', 460000, '2026-04-18 10:45:00', 'ADMIN_02', '2026-04-18 10:45:00', 'ADMIN_02'),
('PUR202604088', '2026-04-18 13:30:00', 'ST001', 'SUP13', 650000, '2026-04-18 13:30:00', 'ADMIN_02', '2026-04-18 13:30:00', 'ADMIN_02'),
('PUR202604089', '2026-04-18 15:00:00', 'ST001', 'SUP14', 1900000, '2026-04-18 15:00:00', 'ADMIN_02', '2026-04-18 15:00:00', 'ADMIN_02'),
('PUR202604090', '2026-04-18 16:30:00', 'ST001', 'SUP15', 3000000, '2026-04-18 16:30:00', 'ADMIN_02', '2026-04-18 16:30:00', 'ADMIN_02'),
('PUR202604091', '2026-04-19 09:00:00', 'ST001', 'SUP16', 780000, '2026-04-19 09:00:00', 'ADMIN_02', '2026-04-19 09:00:00', 'ADMIN_02'),
('PUR202604092', '2026-04-19 10:00:00', 'ST001', 'SUP17', 2300000, '2026-04-19 10:00:00', 'ADMIN_02', '2026-04-19 10:00:00', 'ADMIN_02'),
('PUR202604093', '2026-04-19 11:00:00', 'ST001', 'SUP18', 4000000, '2026-04-19 11:00:00', 'ADMIN_02', '2026-04-19 11:00:00', 'ADMIN_02'),
('PUR202604094', '2026-04-19 13:00:00', 'ST001', 'SUP19', 1450000, '2026-04-19 13:00:00', 'ADMIN_02', '2026-04-19 13:00:00', 'ADMIN_02'),
('PUR202604095', '2026-04-19 14:30:00', 'ST001', 'SUP20', 900000, '2026-04-19 14:30:00', 'ADMIN_02', '2026-04-19 14:30:00', 'ADMIN_02'),
('PUR202604096', '2026-04-20 09:00:00', 'ST001', 'SUP21', 140000, '2026-04-20 09:00:00', 'ADMIN_02', '2026-04-20 09:00:00', 'ADMIN_02'),
('PUR202604097', '2026-04-20 10:15:00', 'ST001', 'SUP22', 750000, '2026-04-20 10:15:00', 'ADMIN_02', '2026-04-20 10:15:00', 'ADMIN_02'),
('PUR202604098', '2026-04-20 11:30:00', 'ST001', 'SUP23', 610000, '2026-04-20 11:30:00', 'ADMIN_02', '2026-04-20 11:30:00', 'ADMIN_02'),
('PUR202604099', '2026-04-20 13:45:00', 'ST001', 'SUP24', 420000, '2026-04-20 13:45:00', 'ADMIN_02', '2026-04-20 13:45:00', 'ADMIN_02'),
('PUR202604100', '2026-04-20 15:00:00', 'ST001', 'SUP25', 1380000, '2026-04-20 15:00:00', 'ADMIN_02', '2026-04-20 15:00:00', 'ADMIN_02');

-- Inventory
INSERT INTO inventory (ingredientID, ingredientName, categoryIngredient, currentStock, reorderLevel, reorderAmount, wastedAmount, ingredientCost, supplierID, lastUpdateRestock, createdAt, createdBy, updatedAt, updatedBy) VALUES 
('INGR001', 'Dada Ayam', 'Protein', 100, 20, 50, 5, 12000, 'SUP01', '2026-04-10 08:30:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR002', 'Roti Burger', 'Karbohidrat', 150, 30, 100, 10, 3500, 'SUP03', '2026-04-12 09:00:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR003', 'Daging Sapi (Patty)', 'Protein', 120, 25, 80, 2, 15000, 'SUP03', '2026-04-12 09:15:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR004', 'Keju Lembaran', 'Produk Susu', 200, 40, 100, 0, 4500, 'SUP04', '2026-04-13 07:45:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR005', 'Acar Timun', 'Sayuran', 500, 100, 200, 15, 500, 'SUP05', '2026-04-09 10:00:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR006', 'Tomat Segar', 'Sayuran', 250, 50, 100, 25, 1000, 'SUP04', '2026-04-14 06:30:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR007', 'Saus Tomat', 'Bumbu', 2000, 500, 1000, 0, 100, 'SUP05', '2026-04-05 11:20:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR008', 'Selada Keriting', 'Sayuran', 100, 20, 50, 12, 800, 'SUP02', '2026-04-14 08:10:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR010', 'Kentang Beku', 'Karbohidrat', 100, 20, 50, 8, 25000, 'SUP06', '2026-04-11 14:00:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR011', 'Paha Ayam', 'Protein', 150, 30, 80, 3, 11000, 'SUP01', '2026-04-10 13:45:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR012', 'Nasi Putih', 'Karbohidrat', 300, 50, 150, 5, 4000, 'SUP02', '2026-04-10 09:30:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR013', 'Isian Apel', 'Buah', 80, 15, 40, 1, 8000, 'SUP04', '2026-04-10 16:20:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02'), 
('INGR014', 'Patty Kentang (Hashbrown)', 'Karbohidrat', 100, 20, 50, 4, 6000, 'SUP03', '2026-04-10 07:00:00', '2026-04-15 09:00:00', 'ADMIN_02', '2026-04-15 09:00:00', 'ADMIN_02');

-- Recipe
INSERT INTO recipe (menuID, ingredientID, quantityItem, unitItem, createdAt, createdBy, updatedAt, updatedBy) VALUES 
-- MN01: Classic Burger
('MN01', 'INGR002', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Roti Burger
('MN01', 'INGR003', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Patty Sapi
('MN01', 'INGR008', 10, 'Grams', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Selada

-- MN02: Cheese Burger
('MN02', 'INGR002', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Roti Burger
('MN02', 'INGR003', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Patty Sapi
('MN02', 'INGR004', 1, 'Lembar', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Keju

-- MN03: Double Beef (Tambahan pelengkap)
('MN03', 'INGR002', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Roti Burger
('MN03', 'INGR003', 2, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Patty Sapi (Double)
('MN03', 'INGR004', 2, 'Lembar', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Keju (Double)

-- MN04: Chicken Burger
('MN04', 'INGR002', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Roti Burger
('MN04', 'INGR001', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Dada Ayam

-- MN05: Fried Chicken
('MN05', 'INGR011', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Paha Ayam

-- MN06: French Fries L
('MN06', 'INGR010', 200, 'Grams', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Kentang Beku

-- MN07: Nasi Ayam
('MN07', 'INGR011', 1, 'Pcs', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'), -- Paha Ayam
('MN07', 'INGR012', 1, 'Porsi', '2026-04-15 10:30:00', 'ADMIN_01', '2026-04-15 10:30:00', 'ADMIN_01'); -- Nasi

-- 14. Supplier Purchase Item (Belum bisa dijalani karena kekurangan inventory; belum ada data dalam inventory)
INSERT INTO supplierPurchaseItem (purchaseID, ingredientID, purchaseQuantity, itemCost, createdAt, createdBy, updatedAt, updatedBy) VALUES 
-- Nota 1 (01 April)
('PUR202604001', 'INGR001', 100, 12000, '2026-04-01 09:00:00', 'ADMIN_02', '2026-04-01 09:00:00', 'ADMIN_02'),
('PUR202604001', 'INGR011', 150, 11000, '2026-04-01 09:00:00', 'ADMIN_02', '2026-04-01 09:00:00', 'ADMIN_02'),
-- Nota 2 (01 April)
('PUR202604002', 'INGR012', 100, 4000, '2026-04-01 10:15:00', 'ADMIN_02', '2026-04-01 10:15:00', 'ADMIN_02'),
('PUR202604002', 'INGR008', 50, 800, '2026-04-01 10:15:00', 'ADMIN_02', '2026-04-01 10:15:00', 'ADMIN_02'),
-- Nota 3 (01 April)
('PUR202604003', 'INGR002', 200, 3500, '2026-04-01 11:30:00', 'ADMIN_02', '2026-04-01 11:30:00', 'ADMIN_02'),
('PUR202604003', 'INGR003', 200, 15000, '2026-04-01 11:30:00', 'ADMIN_02', '2026-04-01 11:30:00', 'ADMIN_02'),
-- Nota 4 (01 April)
('PUR202604004', 'INGR004', 100, 4500, '2026-04-01 13:45:00', 'ADMIN_02', '2026-04-01 13:45:00', 'ADMIN_02'),
('PUR202604004', 'INGR006', 150, 1000, '2026-04-01 13:45:00', 'ADMIN_02', '2026-04-01 13:45:00', 'ADMIN_02'),
-- Nota 5 (01 April)
('PUR202604005', 'INGR005', 200, 500, '2026-04-01 15:00:00', 'ADMIN_02', '2026-04-01 15:00:00', 'ADMIN_02'),
('PUR202604005', 'INGR007', 500, 100, '2026-04-01 15:00:00', 'ADMIN_02', '2026-04-01 15:00:00', 'ADMIN_02'),
-- Nota 6 (02 April)
('PUR202604006', 'INGR010', 100, 25000, '2026-04-02 09:00:00', 'ADMIN_02', '2026-04-02 09:00:00', 'ADMIN_02'),
('PUR202604006', 'INGR014', 50, 6000, '2026-04-02 09:00:00', 'ADMIN_02', '2026-04-02 09:00:00', 'ADMIN_02'),
-- Nota 7 (02 April)
('PUR202604007', 'INGR001', 100, 12000, '2026-04-02 10:00:00', 'ADMIN_02', '2026-04-02 10:00:00', 'ADMIN_02'),
('PUR202604007', 'INGR013', 40, 8000, '2026-04-02 10:00:00', 'ADMIN_02', '2026-04-02 10:00:00', 'ADMIN_02'),
-- Nota 8 (02 April)
('PUR202604008', 'INGR002', 150, 3500, '2026-04-02 11:00:00', 'ADMIN_02', '2026-04-02 11:00:00', 'ADMIN_02'),
('PUR202604008', 'INGR004', 100, 4500, '2026-04-02 11:00:00', 'ADMIN_02', '2026-04-02 11:00:00', 'ADMIN_02'),
-- Nota 9 (02 April)
('PUR202604009', 'INGR003', 120, 15000, '2026-04-02 13:00:00', 'ADMIN_02', '2026-04-02 13:00:00', 'ADMIN_02'),
('PUR202604009', 'INGR010', 100, 25000, '2026-04-02 13:00:00', 'ADMIN_02', '2026-04-02 13:00:00', 'ADMIN_02'),
-- Nota 10 (02 April)
('PUR202604010', 'INGR007', 300, 100, '2026-04-02 14:30:00', 'ADMIN_02', '2026-04-02 14:30:00', 'ADMIN_02'),
('PUR202604010', 'INGR005', 100, 500, '2026-04-02 14:30:00', 'ADMIN_02', '2026-04-02 14:30:00', 'ADMIN_02'),
-- Nota 11 (03 April)
('PUR202604011', 'INGR012', 200, 4000, '2026-04-03 09:15:00', 'ADMIN_02', '2026-04-03 09:15:00', 'ADMIN_02'),
('PUR202604011', 'INGR008', 50, 800, '2026-04-03 09:15:00', 'ADMIN_02', '2026-04-03 09:15:00', 'ADMIN_02'),
-- Nota 12 (03 April)
('PUR202604012', 'INGR006', 150, 1000, '2026-04-03 10:45:00', 'ADMIN_02', '2026-04-03 10:45:00', 'ADMIN_02'),
('PUR202604012', 'INGR013', 20, 8000, '2026-04-03 10:45:00', 'ADMIN_02', '2026-04-03 10:45:00', 'ADMIN_02'),
-- Nota 13 (03 April)
('PUR202604013', 'INGR011', 100, 11000, '2026-04-03 13:30:00', 'ADMIN_02', '2026-04-03 13:30:00', 'ADMIN_02'),
('PUR202604013', 'INGR001', 50, 12000, '2026-04-03 13:30:00', 'ADMIN_02', '2026-04-03 13:30:00', 'ADMIN_02'),
-- Nota 14 (03 April)
('PUR202604014', 'INGR004', 200, 4500, '2026-04-03 15:00:00', 'ADMIN_02', '2026-04-03 15:00:00', 'ADMIN_02'),
('PUR202604014', 'INGR002', 100, 3500, '2026-04-03 15:00:00', 'ADMIN_02', '2026-04-03 15:00:00', 'ADMIN_02'),
-- Nota 15 (03 April)
('PUR202604015', 'INGR003', 150, 15000, '2026-04-03 16:30:00', 'ADMIN_02', '2026-04-03 16:30:00', 'ADMIN_02'),
('PUR202604015', 'INGR010', 80, 25000, '2026-04-03 16:30:00', 'ADMIN_02', '2026-04-03 16:30:00', 'ADMIN_02'),
-- Nota 16 (04 April)
('PUR202604016', 'INGR005', 100, 500, '2026-04-04 09:00:00', 'ADMIN_02', '2026-04-04 09:00:00', 'ADMIN_02'),
('PUR202604016', 'INGR006', 100, 1000, '2026-04-04 09:00:00', 'ADMIN_02', '2026-04-04 09:00:00', 'ADMIN_02'),
-- Nota 17 (04 April)
('PUR202604017', 'INGR012', 300, 4000, '2026-04-04 10:00:00', 'ADMIN_02', '2026-04-04 10:00:00', 'ADMIN_02'),
('PUR202604017', 'INGR007', 200, 100, '2026-04-04 10:00:00', 'ADMIN_02', '2026-04-04 10:00:00', 'ADMIN_02'),
-- Nota 18 (04 April)
('PUR202604018', 'INGR001', 100, 12000, '2026-04-04 11:00:00', 'ADMIN_02', '2026-04-04 11:00:00', 'ADMIN_02'),
('PUR202604018', 'INGR003', 100, 15000, '2026-04-04 11:00:00', 'ADMIN_02', '2026-04-04 11:00:00', 'ADMIN_02'),
-- Nota 19 (04 April)
('PUR202604019', 'INGR002', 150, 3500, '2026-04-04 13:00:00', 'ADMIN_02', '2026-04-04 13:00:00', 'ADMIN_02'),
('PUR202604019', 'INGR014', 50, 6000, '2026-04-04 13:00:00', 'ADMIN_02', '2026-04-04 13:00:00', 'ADMIN_02'),
-- Nota 20 (04 April)
('PUR202604020', 'INGR004', 100, 4500, '2026-04-04 14:30:00', 'ADMIN_02', '2026-04-04 14:30:00', 'ADMIN_02'),
('PUR202604020', 'INGR013', 20, 8000, '2026-04-04 14:30:00', 'ADMIN_02', '2026-04-04 14:30:00', 'ADMIN_02'),
-- Nota 21 (05 April)
('PUR202604021', 'INGR008', 50, 800, '2026-04-05 09:00:00', 'ADMIN_02', '2026-04-05 09:00:00', 'ADMIN_02'),
('PUR202604021', 'INGR005', 100, 500, '2026-04-05 09:00:00', 'ADMIN_02', '2026-04-05 09:00:00', 'ADMIN_02'),
-- Nota 22 (05 April)
('PUR202604022', 'INGR006', 150, 1000, '2026-04-05 10:15:00', 'ADMIN_02', '2026-04-05 10:15:00', 'ADMIN_02'),
('PUR202604022', 'INGR007', 200, 100, '2026-04-05 10:15:00', 'ADMIN_02', '2026-04-05 10:15:00', 'ADMIN_02'),
-- Nota 23 (05 April)
('PUR202604023', 'INGR012', 100, 4000, '2026-04-05 11:30:00', 'ADMIN_02', '2026-04-05 11:30:00', 'ADMIN_02'),
('PUR202604023', 'INGR014', 50, 6000, '2026-04-05 11:30:00', 'ADMIN_02', '2026-04-05 11:30:00', 'ADMIN_02'),
-- Nota 24 (05 April)
('PUR202604024', 'INGR010', 50, 25000, '2026-04-05 13:45:00', 'ADMIN_02', '2026-04-05 13:45:00', 'ADMIN_02'),
('PUR202604024', 'INGR011', 100, 11000, '2026-04-05 13:45:00', 'ADMIN_02', '2026-04-05 13:45:00', 'ADMIN_02'),
-- Nota 25 (05 April)
('PUR202604025', 'INGR001', 50, 12000, '2026-04-05 15:00:00', 'ADMIN_02', '2026-04-05 15:00:00', 'ADMIN_02'),
('PUR202604025', 'INGR003', 50, 15000, '2026-04-05 15:00:00', 'ADMIN_02', '2026-04-05 15:00:00', 'ADMIN_02'),
-- Nota 26 (06 April)
('PUR202604026', 'INGR002', 200, 3500, '2026-04-06 09:00:00', 'ADMIN_02', '2026-04-06 09:00:00', 'ADMIN_02'),
('PUR202604026', 'INGR004', 150, 4500, '2026-04-06 09:00:00', 'ADMIN_02', '2026-04-06 09:00:00', 'ADMIN_02'),
-- Nota 27 (06 April)
('PUR202604027', 'INGR005', 200, 500, '2026-04-06 10:15:00', 'ADMIN_02', '2026-04-06 10:15:00', 'ADMIN_02'),
('PUR202604027', 'INGR006', 150, 1000, '2026-04-06 10:15:00', 'ADMIN_02', '2026-04-06 10:15:00', 'ADMIN_02'),
-- Nota 28 (06 April)
('PUR202604028', 'INGR007', 400, 100, '2026-04-06 11:30:00', 'ADMIN_02', '2026-04-06 11:30:00', 'ADMIN_02'),
('PUR202604028', 'INGR008', 50, 800, '2026-04-06 11:30:00', 'ADMIN_02', '2026-04-06 11:30:00', 'ADMIN_02'),
-- Nota 29 (06 April)
('PUR202604029', 'INGR010', 80, 25000, '2026-04-06 13:45:00', 'ADMIN_02', '2026-04-06 13:45:00', 'ADMIN_02'),
('PUR202604029', 'INGR011', 120, 11000, '2026-04-06 13:45:00', 'ADMIN_02', '2026-04-06 13:45:00', 'ADMIN_02'),
-- Nota 30 (06 April)
('PUR202604030', 'INGR012', 150, 4000, '2026-04-06 15:00:00', 'ADMIN_02', '2026-04-06 15:00:00', 'ADMIN_02'),
('PUR202604030', 'INGR013', 30, 8000, '2026-04-06 15:00:00', 'ADMIN_02', '2026-04-06 15:00:00', 'ADMIN_02'),
-- Nota 31 (07 April)
('PUR202604031', 'INGR014', 100, 6000, '2026-04-07 09:00:00', 'ADMIN_02', '2026-04-07 09:00:00', 'ADMIN_02'),
('PUR202604031', 'INGR001', 100, 12000, '2026-04-07 09:00:00', 'ADMIN_02', '2026-04-07 09:00:00', 'ADMIN_02'),
-- Nota 32 (07 April)
('PUR202604032', 'INGR002', 150, 3500, '2026-04-07 10:00:00', 'ADMIN_02', '2026-04-07 10:00:00', 'ADMIN_02'),
('PUR202604032', 'INGR003', 100, 15000, '2026-04-07 10:00:00', 'ADMIN_02', '2026-04-07 10:00:00', 'ADMIN_02'),
-- Nota 33 (07 April)
('PUR202604033', 'INGR004', 100, 4500, '2026-04-07 11:00:00', 'ADMIN_02', '2026-04-07 11:00:00', 'ADMIN_02'),
('PUR202604033', 'INGR005', 150, 500, '2026-04-07 11:00:00', 'ADMIN_02', '2026-04-07 11:00:00', 'ADMIN_02'),
-- Nota 34 (07 April)
('PUR202604034', 'INGR006', 200, 1000, '2026-04-07 13:00:00', 'ADMIN_02', '2026-04-07 13:00:00', 'ADMIN_02'),
('PUR202604034', 'INGR007', 500, 100, '2026-04-07 13:00:00', 'ADMIN_02', '2026-04-07 13:00:00', 'ADMIN_02'),
-- Nota 35 (07 April)
('PUR202604035', 'INGR008', 50, 800, '2026-04-07 14:30:00', 'ADMIN_02', '2026-04-07 14:30:00', 'ADMIN_02'),
('PUR202604035', 'INGR010', 80, 25000, '2026-04-07 14:30:00', 'ADMIN_02', '2026-04-07 14:30:00', 'ADMIN_02'),
-- Nota 36 (08 April)
('PUR202604036', 'INGR011', 120, 11000, '2026-04-08 09:15:00', 'ADMIN_02', '2026-04-08 09:15:00', 'ADMIN_02'),
('PUR202604036', 'INGR012', 200, 4000, '2026-04-08 09:15:00', 'ADMIN_02', '2026-04-08 09:15:00', 'ADMIN_02'),
-- Nota 37 (08 April)
('PUR202604037', 'INGR013', 40, 8000, '2026-04-08 10:45:00', 'ADMIN_02', '2026-04-08 10:45:00', 'ADMIN_02'),
('PUR202604037', 'INGR014', 50, 6000, '2026-04-08 10:45:00', 'ADMIN_02', '2026-04-08 10:45:00', 'ADMIN_02'),
-- Nota 38 (08 April)
('PUR202604038', 'INGR001', 100, 12000, '2026-04-08 13:30:00', 'ADMIN_02', '2026-04-08 13:30:00', 'ADMIN_02'),
('PUR202604038', 'INGR002', 100, 3500, '2026-04-08 13:30:00', 'ADMIN_02', '2026-04-08 13:30:00', 'ADMIN_02'),
-- Nota 39 (08 April)
('PUR202604039', 'INGR003', 150, 15000, '2026-04-08 15:00:00', 'ADMIN_02', '2026-04-08 15:00:00', 'ADMIN_02'),
('PUR202604039', 'INGR004', 100, 4500, '2026-04-08 15:00:00', 'ADMIN_02', '2026-04-08 15:00:00', 'ADMIN_02'),
-- Nota 40 (08 April)
('PUR202604040', 'INGR005', 200, 500, '2026-04-08 16:30:00', 'ADMIN_02', '2026-04-08 16:30:00', 'ADMIN_02'),
('PUR202604040', 'INGR006', 150, 1000, '2026-04-08 16:30:00', 'ADMIN_02', '2026-04-08 16:30:00', 'ADMIN_02'),
-- Nota 41 (09 April)
('PUR202604041', 'INGR007', 300, 100, '2026-04-09 09:00:00', 'ADMIN_02', '2026-04-09 09:00:00', 'ADMIN_02'),
('PUR202604041', 'INGR008', 50, 800, '2026-04-09 09:00:00', 'ADMIN_02', '2026-04-09 09:00:00', 'ADMIN_02'),
-- Nota 42 (09 April)
('PUR202604042', 'INGR010', 100, 25000, '2026-04-09 10:00:00', 'ADMIN_02', '2026-04-09 10:00:00', 'ADMIN_02'),
('PUR202604042', 'INGR011', 150, 11000, '2026-04-09 10:00:00', 'ADMIN_02', '2026-04-09 10:00:00', 'ADMIN_02'),
-- Nota 43 (09 April)
('PUR202604043', 'INGR012', 200, 4000, '2026-04-09 11:00:00', 'ADMIN_02', '2026-04-09 11:00:00', 'ADMIN_02'),
('PUR202604043', 'INGR013', 20, 8000, '2026-04-09 11:00:00', 'ADMIN_02', '2026-04-09 11:00:00', 'ADMIN_02'),
-- Nota 44 (09 April)
('PUR202604044', 'INGR014', 100, 6000, '2026-04-09 13:00:00', 'ADMIN_02', '2026-04-09 13:00:00', 'ADMIN_02'),
('PUR202604044', 'INGR001', 50, 12000, '2026-04-09 13:00:00', 'ADMIN_02', '2026-04-09 13:00:00', 'ADMIN_02'),
-- Nota 45 (09 April)
('PUR202604045', 'INGR002', 100, 3500, '2026-04-09 14:30:00', 'ADMIN_02', '2026-04-09 14:30:00', 'ADMIN_02'),
('PUR202604045', 'INGR003', 100, 15000, '2026-04-09 14:30:00', 'ADMIN_02', '2026-04-09 14:30:00', 'ADMIN_02'),
-- Nota 46 (10 April)
('PUR202604046', 'INGR004', 100, 4500, '2026-04-10 09:00:00', 'ADMIN_02', '2026-04-10 09:00:00', 'ADMIN_02'),
('PUR202604046', 'INGR005', 100, 500, '2026-04-10 09:00:00', 'ADMIN_02', '2026-04-10 09:00:00', 'ADMIN_02'),
-- Nota 47 (10 April)
('PUR202604047', 'INGR006', 150, 1000, '2026-04-10 10:15:00', 'ADMIN_02', '2026-04-10 10:15:00', 'ADMIN_02'),
('PUR202604047', 'INGR007', 300, 100, '2026-04-10 10:15:00', 'ADMIN_02', '2026-04-10 10:15:00', 'ADMIN_02'),
-- Nota 48 (10 April)
('PUR202604048', 'INGR008', 50, 800, '2026-04-10 11:30:00', 'ADMIN_02', '2026-04-10 11:30:00', 'ADMIN_02'),
('PUR202604048', 'INGR010', 80, 25000, '2026-04-10 11:30:00', 'ADMIN_02', '2026-04-10 11:30:00', 'ADMIN_02'),
-- Nota 49 (10 April)
('PUR202604049', 'INGR011', 120, 11000, '2026-04-10 13:45:00', 'ADMIN_02', '2026-04-10 13:45:00', 'ADMIN_02'),
('PUR202604049', 'INGR012', 200, 4000, '2026-04-10 13:45:00', 'ADMIN_02', '2026-04-10 13:45:00', 'ADMIN_02'),
-- Nota 50 (10 April)
('PUR202604050', 'INGR013', 30, 8000, '2026-04-10 15:00:00', 'ADMIN_02', '2026-04-10 15:00:00', 'ADMIN_02'),
('PUR202604050', 'INGR014', 50, 6000, '2026-04-10 15:00:00', 'ADMIN_02', '2026-04-10 15:00:00', 'ADMIN_02');


-- QUERY
-- 1. Distribusi Crew: Melihat Distribusi Jumlah Crew per Posisi
SELECT 
    position, 
    COUNT(crewID) AS Total_Staff 
FROM crews 
GROUP BY position;

-- 2. Supplier Full Detail: Menampilkan Supplier Full Detail
SELECT 
    supplierID, 
    supplierName, 
    contactPerson, 
    supplierAddress,
    createdAt,
    updatedAt
FROM suppliers
ORDER BY supplierName ASC;

-- 3. Total Pendapatan Bersih: Menghitung total uang masuk dari pesanan yang sudah Completed
SELECT SUM(totalAmount) AS Total_Revenue FROM orders WHERE statusID = 3;

-- 4. Rata-rata Nilai Transaksi: Melihat rata-rata pengeluaran pelanggan per satu kali order.
SELECT AVG(totalAmount) AS Average_Order_Value FROM orders;

-- 5. Pendapatan per Toko: Melihat toko mana yang paling produktif.
SELECT storeNumber, SUM(totalAmount) AS Store_Revenue FROM orders GROUP BY storeNumber;

-- 6. Transaksi Tertinggi: Mencari rekor pembelian terbesar dalam satu nota.
SELECT MAX(totalAmount) AS Highest_Transaction FROM orders;

-- 7. Total Diskon Terpakai: Menghitung total nilai diskon yang diberikan melalui promosi.
SELECT SUM(p.discountAmount) AS Total_Discount_Given 
FROM promotions p JOIN orders o ON p.promoCode = o.promoCode;

-- 8. Nilai Aset Inventaris: Total biaya yang tertanam dalam stok barang saat ini.
SELECT SUM(currentStock * ingredientCost) AS Total_Inventory_Value FROM inventory;

-- 9. Bahan Tanpa Stok: List bahan baku yang benar-benar habis.
SELECT ingredientName FROM inventory WHERE currentStock = 0;

-- 10. Daftar Supplier per Bahan: Mengetahui siapa pemasok untuk setiap bahan baku.
SELECT i.ingredientName, s.supplierName 
FROM inventory i JOIN suppliers s ON i.supplierID = s.supplierID;

-- 11. Total Biaya Pembelian ke Supplier: Akumulasi pengeluaran untuk restock bahan baku.
SELECT SUM(totalCost) AS Total_Purchase_Cost FROM supplierPurchases;

-- 12. Bahan yang Paling Sering Waste: Mengurutkan bahan berdasarkan jumlah yang hangus/terbuang.
SELECT ingredientName, wastedAmount FROM inventory ORDER BY wastedAmount DESC;

-- 13. Menu Paling Laris (Kuantitas): Mencari item menu yang paling banyak dipesan.
SELECT m.comboItem, SUM(oi.quantityItem) AS Total_Sold  
FROM menu m 
JOIN orderItems oi ON m.menuID = oi.menuID 
GROUP BY m.comboItem 
ORDER BY Total_Sold DESC;

-- 14. Menu dengan Harga Termahal
SELECT comboItem, itemPrice 
FROM menu 
ORDER BY itemPrice DESC LIMIT 5;

-- 15. Total Item Terjual Hari Ini
SELECT SUM(quantityItem) 
FROM orderItems oi 
JOIN orders o ON oi.orderNumber = o.orderNumber  
WHERE DATE(o.orderDate) = CURDATE();

-- 16. Daftar Menu yang Belum Pernah Dipesan
SELECT comboItem 
FROM menu 
WHERE menuID NOT IN (SELECT DISTINCT menuID FROM orderItems);

-- 17. Top 5 Pelanggan Paling Loyal
SELECT customerID, COUNT(orderNumber) AS Frequency 
FROM orders 
GROUP BY customerID 
ORDER BY Frequency DESC LIMIT 5;

-- 18. Top 5 Pelanggan "Sultan"
SELECT customerID, SUM(totalAmount) AS Total_Spend 
FROM orders 
GROUP BY customerID 
ORDER BY Total_Spend DESC LIMIT 5;

-- 19. Cek Email Pelanggan yang Menggunakan Promo
SELECT DISTINCT c.email 
FROM customers c 
JOIN orders o ON c.customerID = o.customerID 
WHERE o.promoCode IS NOT NULL;

-- 20. Pelanggan Baru Bulan Ini
SELECT customerName, createdAt 
FROM customers 
WHERE MONTH(createdAt) = MONTH(CURDATE());

-- 21. Jumlah Pelanggan per Wilayah (Berdasarkan Alamat):
SELECT storeNumber, COUNT(customerID) 
FROM orders 
GROUP BY storeNumber;

-- 22. Jumlah Kru per Toko
SELECT fullName, storeNumber 
FROM crews 
WHERE position = 'Manager';

-- 23. Kru dengan Performa Penjualan Tertinggi
SELECT c.fullName, COUNT(o.orderNumber) AS Orders_Handled  
FROM crews c 
JOIN orders o ON c.crewID = o.crewID 
GROUP BY c.fullName 
ORDER BY Orders_Handled DESC;

-- 24. Cek Status Order yang Masih Pending
SELECT orderNumber, orderDate 
FROM orders 
WHERE statusID = 1;

-- 25. Riwayat Update User (Audit Trail): Melihat aktivitas admin tertentu.
SELECT * FROM users 
WHERE updatedBy = 'ADMIN_01';

-- 26. Detail Bahan dalam Satu Menu (Resep)
SELECT m.comboItem, i.ingredientName, r.quantityItem  
FROM recipe r 
JOIN menu m ON r.menuID = m.menuID 
JOIN inventory i ON r.ingredientID = i.ingredientID;

-- 27. Biaya Pembelian per Supplier
SELECT s.supplierName, SUM(sp.totalCost) 
FROM suppliers s 
JOIN supplierPurchases sp ON s.supplierID = sp.supplierID 
GROUP BY s.supplierName;

-- 28. Order Terakhir dalam 24 Jam
SELECT * FROM orders 
WHERE orderDate >= NOW() - INTERVAL 1 DAY;

-- 29. Mengecek Lokasi Pengiriman Order (Store Address)
SELECT o.orderNumber, s.storeAddress 
FROM orders o 
JOIN stores s ON o.storeNumber = s.storeNumber;

-- 30. Promosi yang Masih Aktif Hari Ini
SELECT promoCode, discountAmount 
FROM promotions 
WHERE CURDATE() BETWEEN startDate AND endDate;


-- VIEW
-- 1. Total Customer untuk hari ini
CREATE VIEW View_Total_Customer_Today AS
SELECT COUNT(DISTINCT customerID) AS Total_Customers_Today
FROM orders
WHERE DATE(orderDate) = CURDATE();

-- 2. Revenue hari ini
CREATE VIEW View_Revenue_Today AS
SELECT IFNULL(SUM(totalAmount), 0) AS Revenue_Today
FROM orders
WHERE DATE(orderDate) = CURDATE() AND statusID = 3;

-- 3. Active Customers
CREATE VIEW View_Active_Customers AS
SELECT c.customerID, c.customerName, COUNT(o.orderNumber) AS Total_Orders
FROM customers c
JOIN orders o ON c.customerID = o.customerID
GROUP BY c.customerID, c.customerName
HAVING COUNT(o.orderNumber) > 0;

-- 4. Low Stock Items
CREATE VIEW View_Low_Stock_Items AS
SELECT ingredientID, ingredientName, currentStock, reorderLevel
FROM inventory
WHERE currentStock <= reorderLevel;

-- 5. Revenue Overview selama 7 hari
CREATE VIEW View_Revenue_7_Days AS
SELECT DATE(orderDate) AS Order_Date, SUM(totalAmount) AS Daily_Revenue
FROM orders
WHERE orderDate >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND statusID = 3
GROUP BY DATE(orderDate)
ORDER BY Order_Date DESC;

-- 6. Revenue Overview selama 30 hari
CREATE VIEW View_Revenue_30_Days AS
SELECT DATE(orderDate) AS Order_Date, SUM(totalAmount) AS Daily_Revenue
FROM orders
WHERE orderDate >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND statusID = 3
GROUP BY DATE(orderDate)
ORDER BY Order_Date DESC;

-- 7. Revenue Overview selama 3 bulan
CREATE VIEW View_Revenue_3_Months AS
SELECT YEAR(orderDate) AS Year, MONTH(orderDate) AS Month, SUM(totalAmount) AS Monthly_Revenue
FROM orders
WHERE orderDate >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH) AND statusID = 3
GROUP BY YEAR(orderDate), MONTH(orderDate)
ORDER BY Year DESC, Month DESC;

-- 8. Menu yang paling terjual secara all-time
CREATE VIEW View_Top_Selling_Menu AS
SELECT m.menuID, m.comboItem AS Menu_Name, SUM(oi.quantityItem) AS Total_Sold
FROM menu m
JOIN orderItems oi ON m.menuID = oi.menuID
JOIN orders o ON oi.orderNumber = o.orderNumber
WHERE o.statusID = 3
GROUP BY m.menuID, m.comboItem
ORDER BY Total_Sold DESC;

-- 9. Recent orders kapan
CREATE VIEW View_Recent_Orders AS
SELECT orderNumber, orderDate, customerID, totalAmount, statusID
FROM orders
ORDER BY orderDate DESC
LIMIT 10;

-- 10. Inventory yang kritis atau berkurang
CREATE VIEW View_Critical_Inventory AS
SELECT ingredientID, ingredientName, currentStock, reorderLevel, wastedAmount
FROM inventory
WHERE currentStock = 0 OR currentStock < (reorderLevel / 2)
ORDER BY currentStock ASC;

-- 11. List supplier purchase
CREATE VIEW View_Supplier_Purchases AS
SELECT sp.purchaseID, sp.purchaseDate, s.supplierName, sp.totalCost, sp.storeNumber
FROM supplierPurchases sp
JOIN suppliers s ON sp.supplierID = s.supplierID
ORDER BY sp.purchaseDate DESC;

-- 12. Buat View Induk (Untuk Semua Detail Status)
CREATE VIEW View_All_Orders_Detail AS
SELECT 
    o.orderNumber,
    o.orderDate,
    c.customerName,
    os.statusName,
    o.totalAmount
FROM orders o
JOIN customers c ON o.customerID = c.customerID
JOIN orderStatus os ON o.statusID = os.statusID;

-- 13. View khusus Status Pending
CREATE VIEW View_Detail_Pending AS 
SELECT * FROM View_All_Orders_Detail WHERE statusName = 'Pending';

-- 14. View khusus Preparing
CREATE VIEW View_Detail_Preparing AS 
SELECT * FROM View_All_Orders_Detail WHERE statusName = 'Preparing';

-- 15. View khusus Completed
CREATE VIEW View_Detail_Completed AS 
SELECT * FROM View_All_Orders_Detail WHERE statusName = 'Completed';

-- 16. View khusus Cancelled
CREATE VIEW View_Detail_Cancelled AS 
SELECT * FROM View_All_Orders_Detail WHERE statusName = 'Cancelled';

-- 17. Query/View untuk Cek Crew dan Lokasi Store
CREATE VIEW View_Crew_Store_Location AS
SELECT 
    c.crewID,
    c.fullName,
    c.position,
    c.storeNumber,
    s.storeAddress
FROM crews c
JOIN stores s ON c.storeNumber = s.storeNumber;

-- 18. Cek Detail Manager
SELECT * FROM View_Crew_Store_Location 
WHERE position = 'Manager';

-- 19. Cek Detail Kitchen Staff
SELECT * FROM View_Crew_Store_Location 
WHERE position = 'Kitchen Staff';

-- 20. Cek Detail Cashier
SELECT * FROM View_Crew_Store_Location 
WHERE position = 'Cashier';

-- 21. Cek Detail Delivery
SELECT * FROM View_Crew_Store_Location 
WHERE position = 'Delivery'; 

-- 22. Cek Detail Server
SELECT * FROM View_Crew_Store_Location 
WHERE position = 'Server';

-- 23. View Customer dengan Order > 40 Kali
CREATE VIEW View_Loyal_Customers_Frequent AS
SELECT 
    c.customerID, 
    c.customerName, 
    c.phoneNumber, 
    c.email, 
    COUNT(o.orderNumber) AS Total_Orders
FROM customers c
JOIN orders o ON c.customerID = o.customerID
GROUP BY c.customerID, c.customerName, c.phoneNumber, c.email
HAVING COUNT(o.orderNumber) > 40;

-- 24. View Customer dengan Pengeluaran > Rp 4,200,000
CREATE VIEW View_High_Spender_Customers AS
SELECT 
    c.customerID, 
    c.customerName, 
    c.phoneNumber, 
    c.email, 
    SUM(o.totalAmount) AS Total_Spent
FROM customers c
JOIN orders o ON c.customerID = o.customerID
GROUP BY c.customerID, c.customerName, c.phoneNumber, c.email
HAVING SUM(o.totalAmount) > 4200000;

-- 25. View Detail Ingredient Secara Total
CREATE VIEW View_Inventory_Full_Detail AS
SELECT 
    ingredientID, 
    ingredientName, 
    categoryIngredient, 
    currentStock, 
    ingredientCost,
    lastUpdateRestock
FROM inventory;

-- 26. View Indikasi Low Stock (Hampir Habis)
CREATE VIEW View_Inventory_Low_Stock AS
SELECT 
    ingredientID, 
    ingredientName, 
    currentStock, 
    reorderLevel, 
    reorderAmount AS Recommended_Order_Qty,
    (reorderLevel - currentStock) AS Deficit_Amount
FROM inventory
WHERE currentStock <= reorderLevel
ORDER BY currentStock ASC;

-- 27. View Ingredient yang Hangus atau Wasted
CREATE VIEW View_Inventory_Waste_Report AS
SELECT 
    ingredientID, 
    ingredientName, 
    wastedAmount,
    ingredientCost,
    (wastedAmount * ingredientCost) AS Potential_Loss_Amount
FROM inventory
WHERE wastedAmount > 0
ORDER BY Potential_Loss_Amount DESC;

-- 28. View_Critical_Ingredients_Alert
CREATE VIEW View_Critical_Ingredients_Alert AS
SELECT 
    ingredientID, 
    ingredientName, 
    currentStock, 
    reorderLevel,
    -- Menghitung selisih stok dengan batas minimum
    (currentStock - reorderLevel) AS Stock_Margin,
    -- Memberikan label status berdasarkan tingkat kekritisan
    CASE 
        WHEN currentStock = 0 THEN 'OUT OF STOCK'
        WHEN currentStock <= (reorderLevel * 0.5) THEN 'CRITICAL (Below 50% of Reorder Level)'
        ELSE 'WARNING (Near Reorder Level)'
    END AS Urgency_Status
FROM inventory
WHERE currentStock <= reorderLevel
ORDER BY currentStock ASC;

-- 29. View Detail Total Supplier Purchase (Per Transaksi)
CREATE VIEW View_Supplier_Purchase_Details AS
SELECT 
    sp.purchaseID, 
    sp.purchaseDate, 
    s.supplierName, 
    sp.storeNumber,
    st.storeAddress,
    sp.totalCost
FROM supplierPurchases sp
JOIN suppliers s ON sp.supplierID = s.supplierID
JOIN stores st ON sp.storeNumber = st.storeNumber
ORDER BY sp.purchaseDate DESC;
 
-- 30. View Total Pembelanjaan Keseluruhan (Akumulasi)
CREATE VIEW View_Overall_Supply_Expenditure AS
SELECT 
    COUNT(purchaseID) AS Total_Transactions,
    SUM(totalCost) AS Grand_Total_Expenditure,
    MIN(purchaseDate) AS Data_Recorded_Since,
    MAX(purchaseDate) AS Last_Transaction_Date
FROM supplierPurchases;

-- 31. View Performa Penjualan Menu (Revenue per Menu)
CREATE VIEW View_Menu_Sales_Performance AS
SELECT 
    m.menuID,
    m.comboItem AS Menu_Name,
    m.itemPrice AS Unit_Price,
    SUM(oi.quantityItem) AS Total_Quantity_Sold,
    -- Menghitung total revenue: Total barang dipesan * harga menu
    (SUM(oi.quantityItem) * m.itemPrice) AS Total_Revenue_Per_Menu
FROM menu m
LEFT JOIN orderItems oi ON m.menuID = oi.menuID
GROUP BY m.menuID, m.comboItem, m.itemPrice
ORDER BY Total_Revenue_Per_Menu DESC;

-- 32. View Penggunaan Kode Promosi
CREATE VIEW View_Promotion_Usage_Detail AS
SELECT 
    p.promoCode,
    p.discountAmount,
    p.startDate,
    p.endDate,
    COUNT(o.orderNumber) AS Total_Usage_Count,
    -- Opsional: Menghitung total nilai transaksi yang menggunakan promo ini
    IFNULL(SUM(o.totalAmount), 0) AS Total_Revenue_Generated
FROM promotions p
LEFT JOIN orders o ON p.promoCode = o.promoCode
GROUP BY 
    p.promoCode, 
    p.discountAmount, 
    p.startDate, 
    p.endDate
ORDER BY Total_Usage_Count DESC;

-- TESTING VIEW
SELECT * FROM View_Promotion_Usage_Detail;